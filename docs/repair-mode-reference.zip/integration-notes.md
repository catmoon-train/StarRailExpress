# 主工程接入摘录

下面是摘除前散落在修机包以外的代码。只说明接在哪，不是可直接粘贴的补丁。

## 模式注册 `io.wifi.starrailexpress.api.SREGameModes`

```java
import net.exmo.sre.repair.RepairEscapeGameMode;
public static final ResourceLocation REPAIR_ESCAPE_ID = SRE.canyueId("repair_escape");
public static final GameMode REPAIR_ESCAPE_MODE = registerGameMode(new RepairEscapeGameMode(REPAIR_ESCAPE_ID));
```

## 配置 `SREConfig`

```java
@ConfigEntry.Category(value = "gamemodes")
public boolean enableRepairMode = false;
```

语言键 `text.autoconfig.starrailexpress.option.enableRepairMode`。

## 开局 `StartCommand.execute`

`gameMode == REPAIR_ESCAPE_MODE` 且 `!enableRepairMode` 时 `sendFailure(game.start_error.disabled_gamemode)`。
地图支持检查对修机模式跳过（和 mob riot 一样）。

## 地图 `GameUtils.startGame`

修机模式不 `loadMap` / `loadArea`，直接 `trueStartGame`。

## 创造标签 `TMMItems`

```java
ResourceKey<CreativeModeTab> REPAIR_MODE_GROUP = ResourceKey.create(Registries.CREATIVE_MODE_TAB, SRE.id("repair_mode"));
Registry.register(..., REPAIR_MODE_GROUP, FabricItemGroup.builder()
    .title(Component.translatable("itemGroup.starrailexpress.repair_mode"))
    .icon(() -> new ItemStack(ModItems.REPAIR_TOOLBOX))
    .build());
```

物品注册都把这个 key 传给 `register(...)`。除颤器也挂在这个标签上，但类本身不是修机内容。

## 物品 `ModItems`（均 `import net.exmo.sre.repair.content.item.*`）

`REPAIR_TOOLBOX` RepairBoostItem(15)、`SPARE_PARTS` RepairBoostItem(8)、`RESCUE_FLARE`、`VENGEANCE_DERRINGER`、`SANITY_MEDS`、`EMF_READER`、`CRUCIFIX`、`REPAIR_MEDKIT`、`HUNTER_CHAIN/WEAPON/HAMMER/HOOK`、四个 `HUNTER_PLUGIN_*`、`HUNTER_PULSE/BLINK/JAMMER`、`SMOKE_PELLET`、`DECOY_BEACON`、`ESCAPE_GRAPPLE`、八个 `REPAIR_*` 路线道具（RepairRouteItem）、`REPAIR_PRESET_WAND`。

林家 `LinFamilyRoleData` 的可交互物品表含烟雾弹、诱饵、镇静剂；`isKey` 把 `REPAIR_AREA_KEY` / `REPAIR_OLD_KEY` 当成不可丢钥匙。`TMMDescEffects` 把镇静剂算药剂。这些引用随物品一起删除。

## 方块 `ModBlocks`

`REPAIR_STATION`、`HUNTER_CAGE`、`REPAIR_EXIT_GATE`、`REPAIR_SUPPLY_CRATE`、`REPAIR_PALLET`、`HUNTER_SNARE`、`HOTBAR_STORAGE`（id `repair_hotbar_storage`），以及 `REPAIR_STATION_BLOCK_ENTITY`、`HUNTER_CAGE_BLOCK_ENTITY`、`HOTBAR_STORAGE_BLOCK_ENTITY_BLOCK_ENTITY_TYPE`。

地图介绍 `MapIntroduceScreen.sceneBlockItems` 列过 `HOTBAR_STORAGE`。

## 组件

```java
public static final ComponentKey<RepairRolePlayerComponent> REPAIR_ROLES = ComponentRegistry.getOrCreate(
    ResourceLocation.fromNamespaceAndPath(Noellesroles.MOD_ID, "repair_roles"),
    RepairRolePlayerComponent.class);
registry.beginRegistration(Player.class, REPAIR_ROLES)
    .respawnStrategy(RespawnCopyStrategy.ALWAYS_COPY)
    .end(RepairRolePlayerComponent::new);
```

`fabric.mod.json` 的 `custom.cardinal-components` 含 `"noellesroles:repair_roles"`。

## 网络 `ModPackets`

S2C：`OpenRepairStationScreen`、`RepairCoinReward`、`RepairCombatFeedback`、`OpenRepairRoleSelection`、`OpenRepairRoleShop`。
C2S + `registerGlobalReceiver`：`RepairStationAction`、`RepairRoleSelect`、`RepairRoleShopPurchase`、`RepairPrimarySkill`、`RepairCarryStruggle`、`RepairSearchBegin`、`RepairSearchCancel`。

客户端 `NoellesrolesClient` 收这些包并打开三个 Screen；`HunterCageBlockEntityRenderer` 注册在 `HUNTER_CAGE_BLOCK_ENTITY`。tick 里倒地/被背时发 `RepairCarryStruggleC2SPacket`，对着储物箱按住使用发搜索包。

## 命令与事件

`NRCommandRegister`：`RepairShopCommand`、`RepairStartCommand`、`RepairRoleCommand`、`RepairMapCommand`、`RepairPresetCommand`。
`NREventRegister`：`RepairCombatEvents.register()`、`RepairWorldInteractions.register()`。
`SREHelpCommand` 的 noelle 分类列了 `/cy:repairshop`、`/cy:repair start`、`/cy:repairrole`、`/cy:repairmap`、`/cy:repairpreset`。

## 商店 `RoleShopHandler.registerRepairModeShops`

在 `shopRegister()` 里调用。按 `RepairRoles` 的 id 写入 `ShopContent.customEntries`：狱卒、蛮力、追踪、机械师、医疗、跑者、档案员、破坏者、收藏家。

## 其它客户端

- `CommonClientHudRenderer.registerRenderersEvent` 调 `RepairEscapeHud.register()`
- `ClientAbilityHandler`：修机进行中且已有修机职业或处于背人状态时，能力键发送 `RepairPrimarySkillC2SPacket` 并 return
- `ImmersiveFilterShader.initPasses` 调 `addRepairEscapePass`，着色器 pass 名 `repair_escape`
- `AgentListenStepHandler.canUseListenPassive`：`RepairRoles.REPAIR_HUNTER` 或修机猎手阵营返回 true
- `SpawnMixin.onDeath`：`RepairModeState.downPlayer` 成功则取消死亡
- `DioSwimPoseMixin` / `CantControlMixin`：`downed || carriedBy != null || trialStand.present()` 时取消姿态更新 / 锁热键

## 职业池过滤

以下位置用 `!(role instanceof RepairRole)` 把修机职业挡在谋杀池外。职业类删除后，这些判断一并删除。

- `SREMurderGameMode.getAllRoles` 四个池
- `SREHideAndSeekGameMode` 三个池
- `SREClassChangeGameMode.buildAvailableRoles`
- `SingleSelectDraftState`、`LightningDraftState`、`VolunteerDraftState` 四个池
- `RecorderScreen`、`ConspiratorScreen`、`DictatorBookScreen`、`VolunteerOpenSelectScreen`、`AbstractRoleRosterScreen.isRosterEligible`
- `RoleIntroduceScreen` 的 `IntroductionGameMode.REPAIR`、`isRepairRole`、`isRepairItem`，以及 `shouldHideModeButton` 里对 `REPAIR_ESCAPE_ID` 的分支

`GooseDuckRoles` 只有一句注释提到修机写法，注释改成不再点名已删除的类。
