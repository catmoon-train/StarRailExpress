/*
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package net.exmo.sre.repair.content.item;

import io.wifi.starrailexpress.util.AdventureUsable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.exmo.sre.repair.content.block_entity.RepairStationBlockEntity;
import net.exmo.sre.repair.state.RepairModeState;

import java.util.List;

/** 修机模式全程是冒险模式，不实现 AdventureUsable 的话 ItemStack#useOn 会直接 PASS 掉。 */
public class RepairBoostItem extends Item implements AdventureUsable {
    private final int boost;
    private final String tooltipKey;

    public RepairBoostItem(int boost, String tooltipKey, Properties properties) {
        super(properties);
        this.boost = boost;
        this.tooltipKey = tooltipKey;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel().isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos();
        if (!(context.getLevel().getBlockEntity(pos) instanceof RepairStationBlockEntity station)) {
            return InteractionResult.PASS;
        }
        if (!(context.getPlayer() instanceof ServerPlayer player) || !RepairModeState.canUseSurvivorUtility(player)) {
            return InteractionResult.FAIL;
        }
        if (station.addProgress(boost)) {
            if (context.getLevel() instanceof ServerLevel level) {
                level.playSound(null, pos, SoundEvents.IRON_GOLEM_REPAIR, SoundSource.PLAYERS, 0.75F, 1.1F);
            }
            RepairModeState.awardCoins(player, 12, "repair_coin_source.boost");
            int boostPercent = Math.max(1, (int) Math.round(boost * 100.0 / RepairModeState.REPAIR_STATION_MAX_PROGRESS));
            player.displayClientMessage(Component.translatable("message.noellesroles.repair.boosted", boostPercent,
                    station.getProgressPercent()), true);
            player.displayClientMessage(Component.translatable("message.noellesroles.repair.coin_reward", 12)
                    .withStyle(ChatFormatting.GOLD), true);
            RepairModeState.addNeutralTaskProgress(player, "collector", 1, RepairModeState.COLLECTOR_TASK_NEEDED);
            if ("mechanic".equals(org.agmas.noellesroles.component.ModComponents.REPAIR_ROLES.get(player).activeRole)) {
                RepairModeState.startSkillCooldown(player, 20 * 28, "mechanic_overload");
            }
            if (!player.getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(tooltipKey).withStyle(ChatFormatting.GRAY));
    }
}
