# 漏网：修机处决死因

上一轮只清了 `net.exmo.sre.repair` 包和它的注册点。死因表还留着一条只被修机审判笼使用的 id。

文件：`src/main/java/io/wifi/starrailexpress/game/GameConstants.java`
类：`GameConstants.DeathReasons`

```java
public static ResourceLocation REPAIR_TRIAL_EXECUTION = Noellesroles.id("repair_trial_execution");
```

id：`noellesroles:repair_trial_execution`。
对应语言键 `death_reason.noellesroles.repair_trial_execution` 已在上一轮从语言文件摘进 `lang-keys.json`，主工程里没有别的 Java 再读这个常量。

画板识别里的 `DrawingBoardRecognizer.REPAIR_TOOL` 映射的是 `noellesroles:reinforcement`（加固道具），不是修机模式，所以留着。
