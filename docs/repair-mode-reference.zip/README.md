# 修机模式参考归档

这个压缩包是从 StarRailExpress 主工程里摘出来的「修机逃脱」玩法快照，只作参考，不能直接丢回工程编译。

模式 id：`canyuesama:repair_escape`（`SREGameModes.REPAIR_ESCAPE_MODE`）。
实现包：`net.exmo.sre.repair`。玩家数据组件：`noellesroles:repair_roles`（`RepairRolePlayerComponent`，重生时 ALWAYS_COPY）。
开关：`SREConfig.enableRepairMode`。未开启时 `/start` 会拒绝这个模式。

## 玩法

逃脱方修满 5 台修机台后给逃脱大门通电，再从大门离开。抓捕方用利刃、锁链、笼子拖延并处决。中立职业有独立任务（档案员校准次数、破坏者破坏记录、收藏家使用道具）。

场地由 `RepairArenaBuilder` + `RepairManorScene` 在开局时生成庄园，不走普通 Areas 地图加载（见当时 `GameUtils.startGame` 对 `REPAIR_ESCAPE_MODE` 的短路）。

## 包内结构

路径与摘除前的仓库相对路径一致。

- `src/main/java/net/exmo/sre/repair/` 全部 Java
  - `RepairEscapeGameMode` 生命周期
  - `state/RepairModeState` 进度、倒地、金币、速度
  - `role/` 职业定义与注册
  - `logic/` 开局、胜负、背人、理智、HUD 同步
  - `content/` 修机台、笼子、大门、补给箱、道具
  - `network/` 校准、选角、商店、挣扎、搜索
  - `command/` `cy:repair` / `repairshop` / `repairrole` / `repairmap` / `repairpreset`
  - `arena/` 庄园生成
  - `client/` HUD 与三个界面
- `org/agmas/noellesroles/client/HotbarStorageMenu.java`、`HotbarStorageScreen.java`
- `org/agmas/noellesroles/init/ModMenus.java`（菜单 id `starrailexpress:repair_hotbar_storage`）
- 对应的模型、方块状态、贴图、`repair_escape` 后处理着色器
- `lang-keys.json` 摘出的翻译键
- `integration-notes.md` 主工程里被删掉的接入点

## 当时挂在主工程上的点

这些文件仍留在主工程，修机片段已删除。要复原得把下面这些接回去，不能只还原这个包。

- `SREGameModes`：`REPAIR_ESCAPE_ID` / `REPAIR_ESCAPE_MODE`
- `SREConfig.enableRepairMode`
- `StartCommand`：未开配置则禁止开局
- `GameUtils.startGame`：跳过 Areas
- `TMMItems.REPAIR_MODE_GROUP` 创造标签
- `ModItems`：工具箱、零件、镇静剂、EMF、十字、医疗包、猎手武器/插件、烟雾弹、诱饵、逃脱钩爪、路线钥匙、预设棒
- `ModBlocks`：修机台、笼子、大门、补给箱、木板、陷阱、快捷栏储物箱及其方块实体
- `ModComponents.REPAIR_ROLES` + `fabric.mod.json` 的 `noellesroles:repair_roles`
- `ModPackets` 与 `NoellesrolesClient` 的包注册、挣扎输入、搜索输入、笼子 BER
- `NRCommandRegister` / `NREventRegister` / `RoleShopHandler.registerRepairModeShops`
- `CommonClientHudRenderer` 里的 `RepairEscapeHud.register()`
- `ClientAbilityHandler` 的 G 键改发 `RepairPrimarySkillC2SPacket`
- `ImmersiveFilterShader.addRepairEscapePass`
- `AgentListenStepHandler` 给修机猎手的听声被动
- `SpawnMixin` 用 `RepairModeState.downPlayer` 取消死亡
- `DioSwimPoseMixin` / `CantControlMixin` 在倒地、被背、受审时锁姿态和按键
- 谋杀、躲猫猫、换职、轮换、志愿者选角池里的 `!(role instanceof RepairRole)` 过滤
- 介绍界面的「修机」模式页

除颤器 `ModItems.DEFIBRILLATOR` 不是修机道具，只是当时放进了修机创造标签。摘除时改挂到 `ROLE_ITEMS_GROUP`。

## 翻译

`lang-keys.json` 是从各语言文件里按键名摘出来的副本。主工程语言文件里这些键已经删掉。键名含 `repair`、`hunter_`、`spare_parts`、`rescue_flare`、`sanity_meds`、`smoke_pellet`、`decoy_beacon`、`escape_grapple`、`crucifix`、`emf_reader`、`vengeance_derringer`，以及更新日志里的修机段落。

命令文档 `COMMANDS.md`、`docs/commands.md` 和 `sre_commands` 语言里的 `cy:repair*` 条目也已从主工程去掉，原文说明在 `integration-notes.md`。
