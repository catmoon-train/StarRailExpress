<?php

declare(strict_types=1);

function viewer_config(): array
{
    static $config = null;

    if ($config !== null) {
        return $config;
    }

    $configFile = __DIR__ . '/config.php';
    $sampleFile = __DIR__ . '/config.sample.php';

    if (is_file($configFile)) {
        $loaded = require $configFile;
    } else {
        $loaded = require $sampleFile;
    }

    if (!is_array($loaded)) {
        throw new RuntimeException('Invalid viewer config.');
    }

    $config = $loaded;
    return $config;
}

function viewer_pdo(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $config = viewer_config();
    $db = $config['db'];
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $db['host'],
        (int) $db['port'],
        $db['database'],
        $db['charset']
    );

    $pdo = new PDO($dsn, $db['username'], $db['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}

function viewer_table_name(): string
{
    $table = (string) (viewer_config()['table_name'] ?? 'sre_player_sync_data');
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        throw new RuntimeException('Invalid table name.');
    }
    return $table;
}

function viewer_json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function viewer_query_string(string $key, string $default = ''): string
{
    $value = $_GET[$key] ?? $default;
    return is_string($value) ? trim($value) : $default;
}

function viewer_query_int(string $key, int $default): int
{
    $raw = $_GET[$key] ?? $default;
    if (is_numeric($raw)) {
        return (int) $raw;
    }
    return $default;
}

function viewer_decode_payload(?string $payload): mixed
{
    if ($payload === null || $payload === '') {
        return null;
    }

    try {
        return json_decode($payload, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        return $payload;
    }
}

function viewer_payload_preview(?string $payload, int $limit = 140): string
{
    if ($payload === null) {
        return '';
    }

    $flat = preg_replace('/\s+/u', ' ', trim($payload));
    if ($flat === null) {
        $flat = trim($payload);
    }

    if (mb_strlen($flat) <= $limit) {
        return $flat;
    }

    return mb_substr($flat, 0, $limit - 1) . '…';
}