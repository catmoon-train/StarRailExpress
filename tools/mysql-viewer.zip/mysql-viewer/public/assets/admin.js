const state = {
  currentIdentifier: "",
  currentPlayer: null,
  records: {},
  activeTab: "overview",
};

const rawKeys = ["stats", "skins", "mailbox", "progression", "progression_tasks", "nametags", "player_identity"];

const statFields = [
  ["totalPlayTime", "在线时长"],
  ["totalGamesPlayed", "总场次"],
  ["totalWins", "总胜场"],
  ["totalLosses", "总败场"],
  ["totalKills", "总击杀"],
  ["totalDeaths", "总死亡"],
  ["totalTeamKills", "误伤"],
  ["totalLoversWins", "恋人胜场"],
  ["totalCivilianGames", "平民场次"],
  ["totalCivilianWins", "平民胜场"],
  ["totalCivilianKills", "平民击杀"],
  ["totalCivilianDeaths", "平民死亡"],
  ["totalKillerGames", "杀手场次"],
  ["totalKillerWins", "杀手胜场"],
  ["totalKillerKills", "杀手击杀"],
  ["totalKillerDeaths", "杀手死亡"],
  ["totalNeutralGames", "中立场次"],
  ["totalNeutralWins", "中立胜场"],
  ["totalNeutralKills", "中立击杀"],
  ["totalNeutralDeaths", "中立死亡"],
  ["totalSheriffGames", "警长场次"],
  ["totalSheriffWins", "警长胜场"],
  ["totalSheriffKills", "警长击杀"],
  ["totalSheriffDeaths", "警长死亡"],
];

const el = {
  summary: document.getElementById("admin-summary"),
  report: document.getElementById("reconcile-report"),
  refreshOverview: document.getElementById("refresh-overview"),
  refreshIndex: document.getElementById("refresh-index"),
  ensureIndexes: document.getElementById("ensure-indexes"),
  runReconcile: document.getElementById("run-reconcile"),
  profileForm: document.getElementById("player-profile-form"),
  playerIdentifier: document.getElementById("player_identifier"),
  playerMeta: document.getElementById("player-profile-meta"),
  recentPlayers: document.getElementById("recent-players"),
  workspaceTitle: document.getElementById("workspace-title"),
  overview: document.getElementById("player-overview"),
  statsFields: document.getElementById("stats-fields"),
  roleStats: document.getElementById("role-stats-editor"),
  factionCards: document.getElementById("faction-card-editor"),
  equipped: document.getElementById("equipped-editor"),
  unlocked: document.getElementById("unlocked-editor"),
  mailbox: document.getElementById("mailbox-editor"),
  nametags: document.getElementById("nametag-editor"),
  recordEditors: document.getElementById("record-editors"),
  pendingList: document.getElementById("pending-list"),
  globalMailList: document.getElementById("global-mail-list"),
};

async function api(action, method = "GET", body = null, query = {}) {
  const params = new URLSearchParams({ action, ...query });
  const response = await fetch(`./api.php?${params.toString()}`, {
    method,
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await response.json();
  if (!response.ok || !json.ok) {
    throw new Error(json.message || "Request failed.");
  }
  return json;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function notify(message, kind = "info") {
  el.report.textContent = message;
  el.report.dataset.kind = kind;
}

async function runAction(task, successMessage) {
  try {
    const result = await task();
    if (successMessage) {
      notify(successMessage, "success");
    }
    return result;
  } catch (error) {
    notify(error.message || "操作失败", "error");
    throw error;
  }
}

function numberValue(id, fallback = 0) {
  const node = document.getElementById(id);
  const raw = node ? Number(node.value) : fallback;
  return Number.isFinite(raw) ? raw : fallback;
}

function textValue(id) {
  const node = document.getElementById(id);
  return node ? node.value.trim() : "";
}

function splitCommands(text) {
  return text.split("\n").map((line) => line.trim()).filter(Boolean);
}

function requireIdentifier() {
  if (!state.currentIdentifier) {
    throw new Error("请先加载一个玩家。");
  }
  return state.currentIdentifier;
}

function renderSummary(summary) {
  const cards = [
    ["同步记录", summary.total_records ?? 0],
    ["Usercache", summary.usercache_count ?? 0],
    ["Pending", summary.pending_count ?? 0],
    ["全局邮件", summary.global_mail_count ?? 0],
  ];
  el.summary.innerHTML = cards.map(([label, value]) => `
    <article class="metric-card">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </article>
  `).join("");
}

function renderRecentPlayers(players) {
  el.recentPlayers.innerHTML = (players || []).map((player) => `
    <button class="player-chip" type="button" data-identifier="${escapeHtml(player.name || player.uuid)}">
      <strong>${escapeHtml(player.name || player.uuid)}</strong>
      <span>${escapeHtml(player.source || "db")}</span>
    </button>
  `).join("");
  el.recentPlayers.querySelectorAll(".player-chip").forEach((button) => {
    button.addEventListener("click", async () => {
      state.currentIdentifier = button.dataset.identifier || "";
      el.playerIdentifier.value = state.currentIdentifier;
      await runAction(async () => {
        await loadProfile();
        await loadOverview(false);
      }, `已加载 ${state.currentIdentifier}`);
    });
  });
}

function renderPending(items) {
  if (!items || !items.length) {
    el.pendingList.innerHTML = `<div class="record-card"><div class="record-preview">当前没有待投递操作。</div></div>`;
    return;
  }
  el.pendingList.innerHTML = items.map((item) => `
    <article class="record-card">
      <div class="record-top">
        <span class="record-key">${escapeHtml(item.operation_type)}</span>
        <span class="panel-meta">${escapeHtml(item.status)}</span>
      </div>
      <div class="record-player">${escapeHtml(item.player_name)}</div>
      <div class="record-preview">${escapeHtml(item.data_key)} · ${escapeHtml(item.player_uuid || "等待解析")}</div>
      ${item.note ? `<div class="record-preview">${escapeHtml(item.note)}</div>` : ""}
    </article>
  `).join("");
}

function renderGlobalMails(items) {
  if (!items || !items.length) {
    el.globalMailList.innerHTML = `<div class="record-card"><div class="record-preview">当前没有全局邮件。</div></div>`;
    return;
  }
  el.globalMailList.innerHTML = items.map((item) => `
    <article class="record-card">
      <div class="record-top">
        <span class="record-key">${escapeHtml(item.sender)}</span>
        <span class="panel-meta">${escapeHtml(item.active ? "active" : "off")}</span>
      </div>
      <div class="record-player">${escapeHtml(item.title)}</div>
      <div class="record-preview">sent ${escapeHtml(item.sent_at)} · expires ${escapeHtml(item.expires_at)}</div>
    </article>
  `).join("");
}

function recordPayload(key, fallback) {
  return state.records[key]?.payload ?? fallback;
}

function renderOverview() {
  const player = state.currentPlayer;
  if (!player) {
    el.overview.innerHTML = `<div class="empty-state">加载玩家后显示数据概览。</div>`;
    return;
  }
  const stats = recordPayload("stats", {});
  const progression = recordPayload("progression", {});
  const skins = recordPayload("skins", {});
  const mailbox = recordPayload("mailbox", []);
  const nametags = recordPayload("nametags", {});
  const items = [
    ["玩家名", player.player_name || player.identifier],
    ["UUID", player.player_uuid || "未解析"],
    ["来源", player.source || "unknown"],
    ["总场次", stats.totalGamesPlayed || 0],
    ["胜场", stats.totalWins || 0],
    ["等级", progression.level || progression.lv || 1],
    ["金币", skins.coinNum || 0],
    ["抽奖次数", skins.lootChance || 0],
    ["邮箱邮件", Array.isArray(mailbox) ? mailbox.length : 0],
    ["名片数量", Array.isArray(nametags.nameTags) ? nametags.nameTags.length : 0],
  ];
  el.overview.innerHTML = items.map(([label, value]) => `
    <article class="detail-card">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </article>
  `).join("");
}

function renderStats() {
  const stats = recordPayload("stats", {});
  el.statsFields.innerHTML = statFields.map(([key, label]) => `
    <label><span>${escapeHtml(label)}</span><input data-stat-key="${escapeHtml(key)}" type="number" value="${escapeHtml(Number(stats[key] || 0))}"></label>
  `).join("");

  const roleStats = stats.roleStats && typeof stats.roleStats === "object" ? stats.roleStats : {};
  const rows = Object.entries(roleStats).map(([role, values]) => renderRoleRow(role, values || {})).join("");
  el.roleStats.innerHTML = `
    <div class="table-toolbar"><button id="add-role-row" class="ghost-button" type="button">添加角色</button></div>
    <div class="editor-row editor-row-head six-col"><span>角色ID</span><span>场次</span><span>胜</span><span>败</span><span>击杀</span><span>操作</span></div>
    <div id="role-rows">${rows || renderRoleRow("", {})}</div>
  `;
  document.getElementById("add-role-row").addEventListener("click", () => {
    document.getElementById("role-rows").insertAdjacentHTML("beforeend", renderRoleRow("", {}));
  });
  bindRemoveButtons(el.roleStats);
}

function renderRoleRow(role, values) {
  return `
    <div class="editor-row six-col role-row">
      <input data-field="role" value="${escapeHtml(role)}" placeholder="namespace:role">
      <input data-field="timesPlayed" type="number" value="${escapeHtml(Number(values.timesPlayed || 0))}">
      <input data-field="winsAsRole" type="number" value="${escapeHtml(Number(values.winsAsRole || 0))}">
      <input data-field="lossesAsRole" type="number" value="${escapeHtml(Number(values.lossesAsRole || 0))}">
      <input data-field="killsAsRole" type="number" value="${escapeHtml(Number(values.killsAsRole || 0))}">
      <button class="ghost-button remove-row" type="button">删除</button>
      <input data-field="deathsAsRole" type="number" value="${escapeHtml(Number(values.deathsAsRole || 0))}" title="死亡">
      <input data-field="teamKillsAsRole" type="number" value="${escapeHtml(Number(values.teamKillsAsRole || 0))}" title="误伤">
    </div>
  `;
}

function collectStats() {
  const payload = {};
  el.statsFields.querySelectorAll("[data-stat-key]").forEach((input) => {
    payload[input.dataset.statKey] = Number(input.value || 0);
  });
  payload.roleStats = {};
  el.roleStats.querySelectorAll(".role-row").forEach((row) => {
    const role = row.querySelector('[data-field="role"]').value.trim();
    if (!role) return;
    payload.roleStats[role] = {};
    row.querySelectorAll("[data-field]").forEach((input) => {
      if (input.dataset.field !== "role") {
        payload.roleStats[role][input.dataset.field] = Number(input.value || 0);
      }
    });
  });
  return payload;
}

function renderKeyValueEditor(container, object, valueType = "number") {
  const entries = Object.entries(object && typeof object === "object" ? object : {});
  container.innerHTML = (entries.length ? entries : [["", valueType === "number" ? 0 : ""]]).map(([key, value]) => `
    <div class="editor-row key-value-row">
      <input data-field="key" value="${escapeHtml(key)}" placeholder="key">
      <input data-field="value" ${valueType === "number" ? 'type="number"' : 'type="text"'} value="${escapeHtml(value)}" placeholder="value">
      <button class="ghost-button remove-row" type="button">删除</button>
    </div>
  `).join("");
  bindRemoveButtons(container);
}

function collectKeyValueEditor(container, valueType = "number") {
  const result = {};
  container.querySelectorAll(".key-value-row").forEach((row) => {
    const key = row.querySelector('[data-field="key"]').value.trim();
    if (!key) return;
    const value = row.querySelector('[data-field="value"]').value;
    result[key] = valueType === "number" ? Number(value || 0) : value;
  });
  return result;
}

function renderProgression() {
  const progression = recordPayload("progression", {});
  document.getElementById("prog_level").value = Number(progression.level || progression.lv || 1);
  document.getElementById("prog_xp").value = Number(progression.experience || progression.xp || 0);
  document.getElementById("prog_total_xp").value = Number(progression.totalExperience || progression.txp || 0);
  document.getElementById("prog_claimed_coin").value = Number(progression.claimedCoinRewards || progression.ccr || 0);
  document.getElementById("prog_claimed_loot").value = Number(progression.claimedLootRewards || progression.clr || 0);
  document.getElementById("prog_quest_refresh").value = Number(progression.lastQuestRefreshTime || 0);
  document.getElementById("prog_weekly_refresh").value = Number(progression.lastWeeklyRefreshTime || 0);
  renderKeyValueEditor(el.factionCards, progression.factionCards || progression.fc || {}, "number");
}

function collectProgression() {
  return {
    level: numberValue("prog_level", 1),
    experience: numberValue("prog_xp", 0),
    totalExperience: numberValue("prog_total_xp", 0),
    claimedCoinRewards: numberValue("prog_claimed_coin", 0),
    claimedLootRewards: numberValue("prog_claimed_loot", 0),
    lastQuestRefreshTime: numberValue("prog_quest_refresh", 0),
    lastWeeklyRefreshTime: numberValue("prog_weekly_refresh", 0),
    factionCards: collectKeyValueEditor(el.factionCards, "number"),
  };
}

function renderSkins() {
  const skins = recordPayload("skins", {});
  document.getElementById("skins_coin").value = Number(skins.coinNum || 0);
  document.getElementById("skins_loot").value = Number(skins.lootChance || 0);
  renderKeyValueEditor(el.equipped, skins.equipped || {}, "text");
  renderUnlockedEditor(skins.unlocked || {});
}

function renderUnlockedEditor(unlocked) {
  const groups = Object.entries(unlocked && typeof unlocked === "object" ? unlocked : {});
  el.unlocked.innerHTML = (groups.length ? groups : [["", {}]]).map(([group, values]) => `
    <section class="nested-group">
      <div class="editor-row key-value-row">
        <input data-field="group" value="${escapeHtml(group)}" placeholder="物品类型">
        <button class="ghost-button add-skin-row" type="button">添加皮肤</button>
        <button class="ghost-button remove-row" type="button">删除组</button>
      </div>
      <div class="nested-items">
        ${Object.entries(values || {}).map(([skin, enabled]) => renderUnlockedSkinRow(skin, enabled)).join("") || renderUnlockedSkinRow("", true)}
      </div>
    </section>
  `).join("");
  el.unlocked.querySelectorAll(".add-skin-row").forEach((button) => {
    button.addEventListener("click", () => {
      button.closest(".nested-group").querySelector(".nested-items").insertAdjacentHTML("beforeend", renderUnlockedSkinRow("", true));
      bindRemoveButtons(button.closest(".nested-group"));
    });
  });
  bindRemoveButtons(el.unlocked);
}

function renderUnlockedSkinRow(skin, enabled) {
  return `
    <div class="editor-row key-value-row unlocked-row">
      <input data-field="skin" value="${escapeHtml(skin)}" placeholder="skin">
      <label class="check-label"><input data-field="enabled" type="checkbox" ${enabled ? "checked" : ""}> 已解锁</label>
      <button class="ghost-button remove-row" type="button">删除</button>
    </div>
  `;
}

function collectUnlockedEditor() {
  const result = {};
  el.unlocked.querySelectorAll(".nested-group").forEach((groupNode) => {
    const group = groupNode.querySelector('[data-field="group"]').value.trim();
    if (!group) return;
    result[group] = {};
    groupNode.querySelectorAll(".unlocked-row").forEach((row) => {
      const skin = row.querySelector('[data-field="skin"]').value.trim();
      if (!skin) return;
      result[group][skin] = row.querySelector('[data-field="enabled"]').checked;
    });
  });
  return result;
}

function renderMailbox() {
  const mailbox = recordPayload("mailbox", []);
  const mails = Array.isArray(mailbox) ? mailbox : [];
  el.mailbox.innerHTML = mails.map((mail) => renderMailCard(mail)).join("") || `<div class="empty-state">邮箱为空。</div>`;
  bindRemoveButtons(el.mailbox);
}

function renderMailCard(mail = {}) {
  const commands = Array.isArray(mail.commands) ? mail.commands.join("\n") : "";
  return `
    <article class="mail-card">
      <div class="form-grid two-col">
        <label><span>ID</span><input data-field="id" value="${escapeHtml(mail.id || "")}" placeholder="留空自动生成"></label>
        <label><span>发送者</span><input data-field="sender" value="${escapeHtml(mail.sender || "System")}"></label>
        <label><span>标题</span><input data-field="title" value="${escapeHtml(mail.title || "")}"></label>
        <label><span>发送时间</span><input data-field="sentAt" type="number" value="${escapeHtml(Number(mail.sentAt || Date.now()))}"></label>
        <label><span>过期时间</span><input data-field="expiresAt" type="number" value="${escapeHtml(Number(mail.expiresAt || 0))}"></label>
        <div class="checkbox-row">
          <label class="check-label"><input data-field="read" type="checkbox" ${mail.read ? "checked" : ""}> 已读</label>
          <label class="check-label"><input data-field="claimed" type="checkbox" ${mail.claimed ? "checked" : ""}> 已领取</label>
          <button class="ghost-button remove-row" type="button">删除邮件</button>
        </div>
      </div>
      <label><span>正文</span><textarea data-field="content">${escapeHtml(mail.content || "")}</textarea></label>
      <label><span>命令，一行一个</span><textarea data-field="commands">${escapeHtml(commands)}</textarea></label>
    </article>
  `;
}

function collectMailbox() {
  return Array.from(el.mailbox.querySelectorAll(".mail-card")).map((card) => ({
    id: card.querySelector('[data-field="id"]').value.trim(),
    sender: card.querySelector('[data-field="sender"]').value.trim() || "System",
    title: card.querySelector('[data-field="title"]').value.trim(),
    content: card.querySelector('[data-field="content"]').value,
    sentAt: Number(card.querySelector('[data-field="sentAt"]').value || Date.now()),
    expiresAt: Number(card.querySelector('[data-field="expiresAt"]').value || 0),
    read: card.querySelector('[data-field="read"]').checked,
    claimed: card.querySelector('[data-field="claimed"]').checked,
    commands: splitCommands(card.querySelector('[data-field="commands"]').value),
  }));
}

function renderNametags() {
  const nametags = recordPayload("nametags", {});
  document.getElementById("current_nametag").value = nametags.currentNametag || "";
  const list = Array.isArray(nametags.nameTags) ? nametags.nameTags : [];
  el.nametags.innerHTML = list.map((tag) => renderListRow(tag)).join("") || renderListRow("");
  bindRemoveButtons(el.nametags);
}

function renderListRow(value) {
  return `
    <div class="editor-row list-row">
      <input data-field="value" value="${escapeHtml(value)}" placeholder="nametag">
      <button class="ghost-button remove-row" type="button">删除</button>
    </div>
  `;
}

function collectNametags() {
  return {
    currentNametag: textValue("current_nametag"),
    nameTags: Array.from(el.nametags.querySelectorAll('[data-field="value"]')).map((input) => input.value.trim()).filter(Boolean),
  };
}

function renderRawEditors() {
  el.recordEditors.innerHTML = rawKeys.map((key) => {
    const value = state.records[key] ? state.records[key].raw_payload : "{}";
    return `
      <section class="raw-editor-card">
        <div class="panel-head tight-head"><h3>${escapeHtml(key)}</h3></div>
        <textarea data-raw-key="${escapeHtml(key)}">${escapeHtml(value)}</textarea>
        <button class="primary-button raw-save-button" type="button" data-save-key="${escapeHtml(key)}">保存 ${escapeHtml(key)}</button>
      </section>
    `;
  }).join("");
  el.recordEditors.querySelectorAll(".raw-save-button").forEach((button) => {
    button.addEventListener("click", async () => {
      const key = button.dataset.saveKey;
      const textarea = el.recordEditors.querySelector(`textarea[data-raw-key="${key}"]`);
      try {
        JSON.parse(textarea.value);
      } catch {
        notify(`${key} 不是有效 JSON`, "error");
        return;
      }
      await runAction(async () => {
        await api("save_raw", "POST", {
          identifier: requireIdentifier(),
          data_key: key,
          raw_payload: textarea.value,
        });
        await loadProfile();
      }, `${key} 已保存`);
    });
  });
}

function bindRemoveButtons(root) {
  root.querySelectorAll(".remove-row").forEach((button) => {
    button.onclick = () => {
      const card = button.closest(".mail-card");
      const group = button.closest(".nested-group");
      const row = button.closest(".editor-row");
      if (card) card.remove();
      else if (group && button.parentElement?.querySelector('[data-field="group"]')) group.remove();
      else if (row) row.remove();
    };
  });
}

function renderAllEditors() {
  renderOverview();
  renderStats();
  renderProgression();
  renderSkins();
  renderMailbox();
  renderNametags();
  renderRawEditors();
}

async function loadOverview(showNotice = true) {
  const json = await api("admin_overview");
  renderSummary(json.overview.summary);
  renderPending(json.overview.pending);
  renderGlobalMails(json.overview.global_mails);
  renderRecentPlayers(json.overview.recent_players || []);
  if (showNotice) notify("概览已刷新。", "info");
}

async function loadProfile() {
  if (!state.currentIdentifier) return;
  const json = await api("profile", "GET", null, { identifier: state.currentIdentifier });
  state.currentPlayer = json.profile.player;
  state.records = json.profile.records || {};
  const player = state.currentPlayer;
  el.workspaceTitle.textContent = player.player_name || player.identifier || "未命名玩家";
  el.playerMeta.textContent = `当前目标: ${player.player_name || player.identifier} · ${player.player_uuid || "未解析 UUID，将进入待投递队列"} · 来源 ${player.source || "unknown"} · Pending ${json.profile.pending.length}`;
  if (!document.getElementById("mail_recipient").value.trim()) {
    document.getElementById("mail_recipient").value = player.player_name || player.identifier || "";
  }
  renderAllEditors();
}

function bindTabs() {
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.addEventListener("click", () => {
      state.activeTab = button.dataset.tab;
      document.querySelectorAll(".tab-button").forEach((item) => item.classList.toggle("active", item === button));
      document.querySelectorAll(".tab-panel").forEach((panel) => panel.classList.toggle("active", panel.dataset.panel === state.activeTab));
    });
  });
}

function bindEvents() {
  bindTabs();

  el.refreshOverview.addEventListener("click", async () => {
    await runAction(() => loadOverview(), "概览已刷新");
  });
  el.refreshIndex.addEventListener("click", async () => {
    await runAction(async () => {
      const json = await api("refresh_player_index", "POST", {});
      await loadOverview(false);
      const uc = json.refresh.usercache?.indexed ?? 0;
      const st = json.refresh.sync_table?.indexed ?? 0;
      notify(`玩家索引已刷新: usercache=${uc}, sync_table=${st}`, "success");
    });
  });
  el.ensureIndexes.addEventListener("click", async () => {
    await runAction(async () => {
      const json = await api("ensure_indexes", "POST", {});
      const created = json.indexes.created?.join(", ") || "无新增";
      const skipped = json.indexes.skipped?.length ? `；跳过: ${json.indexes.skipped.join(" | ")}` : "";
      notify(`索引优化完成: ${created}${skipped}`, "success");
    });
  });
  el.runReconcile.addEventListener("click", async () => {
    await runAction(async () => {
      const json = await api("reconcile", "POST", {});
      await loadOverview(false);
      if (state.currentIdentifier) await loadProfile();
      const r = json.reconcile;
      notify(`补偿完成: processed=${r.processed}, applied=${r.pending_applied}, waiting=${r.pending_waiting}, conflicts=${r.pending_conflicts}, global=${r.global_mail_applied}`, "success");
    });
  });

  el.profileForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    state.currentIdentifier = el.playerIdentifier.value.trim();
    await runAction(async () => {
      await loadProfile();
      await loadOverview(false);
    }, `已加载 ${state.currentIdentifier}`);
  });

  document.querySelectorAll(".add-row-button").forEach((button) => {
    button.addEventListener("click", () => {
      const container = document.getElementById(button.dataset.target);
      const valueInput = button.dataset.target === "equipped-editor"
        ? '<input data-field="value" type="text" placeholder="skin">'
        : '<input data-field="value" type="number" value="0" placeholder="value">';
      container.insertAdjacentHTML("beforeend", `
        <div class="editor-row key-value-row">
          <input data-field="key" placeholder="key">
          ${valueInput}
          <button class="ghost-button remove-row" type="button">删除</button>
        </div>
      `);
      bindRemoveButtons(container);
    });
  });

  document.getElementById("add-unlocked-group").addEventListener("click", () => {
    el.unlocked.insertAdjacentHTML("beforeend", `
      <section class="nested-group">
        <div class="editor-row key-value-row">
          <input data-field="group" placeholder="物品类型">
          <button class="ghost-button add-skin-row" type="button">添加皮肤</button>
          <button class="ghost-button remove-row" type="button">删除组</button>
        </div>
        <div class="nested-items">${renderUnlockedSkinRow("", true)}</div>
      </section>
    `);
    const group = el.unlocked.lastElementChild;
    group.querySelector(".add-skin-row").addEventListener("click", () => {
      group.querySelector(".nested-items").insertAdjacentHTML("beforeend", renderUnlockedSkinRow("", true));
      bindRemoveButtons(group);
    });
    bindRemoveButtons(group);
  });

  document.getElementById("add-mail-row").addEventListener("click", () => {
    const empty = el.mailbox.querySelector(".empty-state");
    if (empty) empty.remove();
    el.mailbox.insertAdjacentHTML("beforeend", renderMailCard({ sentAt: Date.now(), sender: "System" }));
    bindRemoveButtons(el.mailbox);
  });

  document.getElementById("add-nametag").addEventListener("click", () => {
    el.nametags.insertAdjacentHTML("beforeend", renderListRow(""));
    bindRemoveButtons(el.nametags);
  });

  document.getElementById("stats-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      await api("save_stats", "POST", { identifier: requireIdentifier(), ...collectStats() });
      await loadProfile();
    }, "统计已保存");
  });

  document.getElementById("progression-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      await api("save_progression", "POST", { identifier: requireIdentifier(), ...collectProgression() });
      await loadProfile();
    }, "通行证已保存");
  });

  document.getElementById("skins-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      await api("save_skins", "POST", {
        identifier: requireIdentifier(),
        coinNum: numberValue("skins_coin"),
        lootChance: numberValue("skins_loot"),
        equipped: collectKeyValueEditor(el.equipped, "text"),
        unlocked: collectUnlockedEditor(),
      });
      await loadProfile();
    }, "皮肤已保存");
  });

  document.getElementById("mailbox-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      await api("save_mailbox", "POST", { identifier: requireIdentifier(), mails: collectMailbox() });
      await loadProfile();
    }, "邮箱已保存");
  });

  document.getElementById("nametags-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      await api("save_nametags", "POST", { identifier: requireIdentifier(), ...collectNametags() });
      await loadProfile();
    }, "名片已保存");
  });

  document.querySelectorAll(".faction-grant-button").forEach((button) => {
    button.addEventListener("click", async () => {
      await runAction(async () => {
        await api("grant_faction_card", "POST", {
          identifier: requireIdentifier(),
          faction: button.dataset.faction,
          amount: numberValue("faction_amount", 1),
        });
        await loadProfile();
      }, `已给予 ${button.dataset.faction} 阵营卡`);
    });
  });

  document.getElementById("mail-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      const recipient = textValue("mail_recipient") || requireIdentifier();
      const result = await api("send_mail", "POST", {
        recipient,
        sender: textValue("mail_sender"),
        title: textValue("mail_title"),
        content: document.getElementById("mail_content").value.trim(),
        commands: splitCommands(document.getElementById("mail_commands").value),
        expiresAt: numberValue("mail_expires", 0),
      });
      await loadOverview(false);
      if (state.currentIdentifier) await loadProfile();
      const s = result.summary || {};
      notify(`邮件处理完成: total=${s.total || 1}, applied=${s.applied || 0}, queued=${s.queued || 0}`, "success");
    });
  });

  document.getElementById("global-mail-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAction(async () => {
      await api("create_global_mail", "POST", {
        sender: textValue("global_sender"),
        title: textValue("global_title"),
        content: document.getElementById("global_content").value.trim(),
        commands: splitCommands(document.getElementById("global_commands").value),
        expiresAt: numberValue("global_expires", 0),
      });
      await loadOverview(false);
    }, "全局邮件已创建，执行补偿后批量投递");
  });
}

async function boot() {
  bindEvents();
  renderAllEditors();
  try {
    await loadOverview();
  } catch (error) {
    notify(error.message || "加载失败", "error");
  }
}

boot();
