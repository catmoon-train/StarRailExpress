// StarRailExpress — Public Player Dashboard

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function buildKvTable(rows) {
  if (!rows || !rows.length) {
    return '<p class="pub-empty">暂无数据</p>';
  }
  const rowsHtml = rows
    .map(
      (r) =>
        `<tr><td class="kv-label">${escapeHtml(r.label)}</td><td class="kv-value">${escapeHtml(String(r.value))}</td></tr>`
    )
    .join("");
  return `<table class="pub-kv-table"><tbody>${rowsHtml}</tbody></table>`;
}

function buildFactionTable(rows) {
  if (!rows || !rows.length) {
    return '<p class="pub-empty">暂无数据</p>';
  }
  const rowsHtml = rows
    .map(
      (r) =>
        `<tr>
          <td class="kv-label">${escapeHtml(r.faction)}</td>
          <td class="kv-value">${escapeHtml(String(r.games))}</td>
          <td class="kv-value">${escapeHtml(String(r.wins))}</td>
          <td class="kv-value">${escapeHtml(String(r.kills))}</td>
          <td class="kv-value">${escapeHtml(String(r.deaths))}</td>
        </tr>`
    )
    .join("");
  return `<table class="pub-faction-table">
    <thead><tr>
      <th>阵营</th><th>场次</th><th>胜场</th><th>击杀</th><th>死亡</th>
    </tr></thead>
    <tbody>${rowsHtml}</tbody>
  </table>`;
}

function buildRoleTable(rows) {
  if (!rows || !rows.length) {
    return '<p class="pub-empty">暂无角色数据</p>';
  }
  const rowsHtml = rows
    .map(
      (r) =>
        `<tr>
          <td class="kv-label">${escapeHtml(r.role)}</td>
          <td class="kv-value">${escapeHtml(String(r.timesPlayed))}</td>
          <td class="kv-value">${escapeHtml(String(r.winsAsRole))}</td>
          <td class="kv-value">${escapeHtml(String(r.killsAsRole))}</td>
          <td class="kv-value">${escapeHtml(String(r.deathsAsRole))}</td>
        </tr>`
    )
    .join("");
  return `<table class="pub-faction-table">
    <thead><tr>
      <th>角色</th><th>场次</th><th>胜场</th><th>击杀</th><th>死亡</th>
    </tr></thead>
    <tbody>${rowsHtml}</tbody>
  </table>`;
}

function buildFactionCardsTable(cards) {
  if (!cards || !cards.length) {
    return '<p class="pub-empty">暂无阵营卡</p>';
  }
  const rows = cards.map(
    (c) =>
      `<tr><td class="kv-label">${escapeHtml(c.name)}</td><td class="kv-value">${escapeHtml(String(c.count))}</td></tr>`
  );
  return `<table class="pub-kv-table"><tbody>${rows.join("")}</tbody></table>`;
}

function showNotice(msg, kind = "error") {
  const el = document.getElementById("search-notice");
  el.textContent = msg;
  el.setAttribute("data-kind", kind);
  el.style.display = "";
}

function hideNotice() {
  const el = document.getElementById("search-notice");
  el.style.display = "none";
}

function renderDashboard(data) {
  const { player, dashboard } = data;

  // Player header
  document.getElementById("player-username").textContent = player.username || player.identifier;
  document.getElementById("player-uuid").textContent = player.uuid || "UUID 未知";

  const sourceMap = {
    usercache: "从用户缓存",
    player_index: "从玩家索引",
    sync_table: "从同步数据",
    pending: "从待处理队列",
  };
  document.getElementById("player-source-badge").textContent =
    sourceMap[player.source] || "已找到";

  // Avatar placeholder using first character
  const avatarWrap = document.getElementById("player-avatar-wrap");
  const initial = (player.username || player.identifier || "?")[0].toUpperCase();
  avatarWrap.innerHTML = `<div class="pub-avatar-circle">${escapeHtml(initial)}</div>`;

  // Tables
  document.getElementById("table-stats").innerHTML = buildKvTable(dashboard.statsRows);
  document.getElementById("table-progress").innerHTML = buildKvTable(dashboard.progressRows);
  document.getElementById("table-faction-cards").innerHTML = buildFactionCardsTable(dashboard.factionCards);
  document.getElementById("table-factions").innerHTML = buildFactionTable(dashboard.factionRows);
  document.getElementById("table-skins").innerHTML = buildKvTable(dashboard.skinRows);
  document.getElementById("table-mail").innerHTML = buildKvTable(dashboard.mailRows);

  // Role rows (optional)
  const roleSection = document.getElementById("role-section");
  if (dashboard.roleRows && dashboard.roleRows.length > 0) {
    document.getElementById("table-roles").innerHTML = buildRoleTable(dashboard.roleRows);
    document.getElementById("role-count").textContent = `共 ${dashboard.roleRows.length} 个角色`;
    roleSection.style.display = "";
  } else {
    roleSection.style.display = "none";
  }

  document.getElementById("dashboard-root").style.display = "";
  document.getElementById("dashboard-root").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function doSearch(username) {
  hideNotice();
  if (!username) {
    showNotice("请输入用户名");
    return;
  }

  const btn = document.querySelector('#search-form button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "查询中…";

  try {
    const params = new URLSearchParams({ action: "player_dashboard", identifier: username });
    const res = await fetch(`./api.php?${params.toString()}`);
    const json = await res.json();
    if (!json.ok) {
      document.getElementById("dashboard-root").style.display = "none";
      showNotice(json.message || "未找到该玩家");
      return;
    }
    renderDashboard(json);
  } catch (err) {
    document.getElementById("dashboard-root").style.display = "none";
    showNotice("请求失败：" + err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = "查询";
  }
}

document.getElementById("search-form").addEventListener("submit", (e) => {
  e.preventDefault();
  doSearch(document.getElementById("username-input").value.trim());
});

// Support ?u=username in URL for direct links
(function () {
  const params = new URLSearchParams(window.location.search);
  const u = params.get("u");
  if (u) {
    document.getElementById("username-input").value = u;
    doSearch(u);
  }
})();
