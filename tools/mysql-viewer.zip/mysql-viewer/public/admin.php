<?php

declare(strict_types=1);

require __DIR__ . '/_app/bootstrap.php';
viewer_require_auth_for_page();

$config = viewer_config();
$siteTitle = (string) ($config['site_title'] ?? 'StarRailExpress Sync Viewer');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8') ?> Admin</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body class="admin-body">
    <div class="admin-shell">
        <header class="admin-commandbar">
            <div>
                <p class="eyebrow">Database Control Center</p>
                <h1><?= htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8') ?></h1>
            </div>
            <nav class="admin-actions">
                <button id="refresh-overview" class="ghost-button" type="button">刷新概览</button>
                <button id="refresh-index" class="ghost-button" type="button">刷新玩家索引</button>
                <button id="ensure-indexes" class="ghost-button" type="button">优化索引</button>
                <button id="run-reconcile" class="primary-button" type="button">执行补偿</button>
                <a class="ghost-link" href="./index.php">玩家查询</a>
                <a class="ghost-link" href="./api.php?action=logout">退出</a>
            </nav>
        </header>

        <main class="admin-grid">
            <aside class="admin-sidebar">
                <section class="tool-panel">
                    <div class="panel-head tight-head">
                        <h2>玩家搜索</h2>
                    </div>
                    <form id="player-profile-form" class="stack-form">
                        <label>
                            <span>用户名 / UUID</span>
                            <input id="player_identifier" type="text" placeholder="kekedisama 或 UUID">
                        </label>
                        <button class="primary-button" type="submit">加载玩家</button>
                    </form>
                    <div id="player-profile-meta" class="status-box">先加载一个玩家。</div>
                    <div id="recent-players" class="quick-player-list admin-chip-list"></div>
                </section>

                <section class="tool-panel">
                    <div class="panel-head tight-head">
                        <h2>系统状态</h2>
                    </div>
                    <div id="admin-summary" class="metric-grid"></div>
                    <div id="reconcile-report" class="status-box">等待加载概览。</div>
                </section>
            </aside>

            <section class="workspace-panel">
                <div class="workspace-head">
                    <div>
                        <p class="eyebrow">Player Editor</p>
                        <h2 id="workspace-title">未选择玩家</h2>
                    </div>
                    <div class="tab-row" role="tablist">
                        <button class="tab-button active" type="button" data-tab="overview">概览</button>
                        <button class="tab-button" type="button" data-tab="stats">统计</button>
                        <button class="tab-button" type="button" data-tab="progression">通行证</button>
                        <button class="tab-button" type="button" data-tab="skins">皮肤</button>
                        <button class="tab-button" type="button" data-tab="mailbox">邮箱</button>
                        <button class="tab-button" type="button" data-tab="nametags">名片</button>
                        <button class="tab-button" type="button" data-tab="raw">JSON</button>
                    </div>
                </div>

                <section class="tab-panel active" data-panel="overview">
                    <div id="player-overview" class="detail-grid"></div>
                </section>

                <section class="tab-panel" data-panel="stats">
                    <form id="stats-form" class="stack-form">
                        <div id="stats-fields" class="form-grid three-col"></div>
                        <h3>角色统计</h3>
                        <div id="role-stats-editor" class="editable-table"></div>
                        <button class="primary-button" type="submit">保存统计</button>
                    </form>
                </section>

                <section class="tab-panel" data-panel="progression">
                    <form id="progression-form" class="stack-form">
                        <div class="form-grid three-col">
                            <label><span>等级</span><input id="prog_level" type="number" value="1"></label>
                            <label><span>当前经验</span><input id="prog_xp" type="number" value="0"></label>
                            <label><span>总经验</span><input id="prog_total_xp" type="number" value="0"></label>
                            <label><span>已领金币奖励</span><input id="prog_claimed_coin" type="number" value="0"></label>
                            <label><span>已领抽奖奖励</span><input id="prog_claimed_loot" type="number" value="0"></label>
                            <label><span>任务刷新时间</span><input id="prog_quest_refresh" type="number" value="0"></label>
                            <label><span>周刷新时间</span><input id="prog_weekly_refresh" type="number" value="0"></label>
                        </div>
                        <h3>阵营卡</h3>
                        <div id="faction-card-editor" class="key-value-editor"></div>
                        <button class="ghost-button add-row-button" type="button" data-target="faction-card-editor">添加阵营卡</button>
                        <button class="primary-button" type="submit">保存通行证</button>
                    </form>
                </section>

                <section class="tab-panel" data-panel="skins">
                    <form id="skins-form" class="stack-form">
                        <div class="form-grid two-col">
                            <label><span>金币</span><input id="skins_coin" type="number" value="0"></label>
                            <label><span>抽奖次数</span><input id="skins_loot" type="number" value="0"></label>
                        </div>
                        <h3>装备皮肤</h3>
                        <div id="equipped-editor" class="key-value-editor"></div>
                        <button class="ghost-button add-row-button" type="button" data-target="equipped-editor">添加装备项</button>
                        <h3>已解锁皮肤</h3>
                        <div id="unlocked-editor" class="nested-editor"></div>
                        <button class="ghost-button" id="add-unlocked-group" type="button">添加解锁组</button>
                        <button class="primary-button" type="submit">保存皮肤</button>
                    </form>
                </section>

                <section class="tab-panel" data-panel="mailbox">
                    <form id="mailbox-form" class="stack-form">
                        <div class="table-toolbar">
                            <button id="add-mail-row" class="ghost-button" type="button">新增邮件</button>
                        </div>
                        <div id="mailbox-editor" class="mail-editor"></div>
                        <button class="primary-button" type="submit">保存邮箱</button>
                    </form>
                </section>

                <section class="tab-panel" data-panel="nametags">
                    <form id="nametags-form" class="stack-form">
                        <label><span>当前名片</span><input id="current_nametag" type="text"></label>
                        <h3>名片列表</h3>
                        <div id="nametag-editor" class="list-editor"></div>
                        <button id="add-nametag" class="ghost-button" type="button">添加名片</button>
                        <button class="primary-button" type="submit">保存名片</button>
                    </form>
                </section>

                <section class="tab-panel" data-panel="raw">
                    <div id="record-editors" class="raw-editor-grid"></div>
                </section>
            </section>

            <aside class="admin-quickbar">
                <section class="tool-panel">
                    <div class="panel-head tight-head">
                        <h2>快捷操作</h2>
                    </div>
                    <form id="mail-form" class="stack-form">
                        <label><span>收件人</span><input id="mail_recipient" type="text" placeholder="支持 p1,p2,p3"></label>
                        <label><span>发送者</span><input id="mail_sender" type="text" value="System"></label>
                        <label><span>标题</span><input id="mail_title" type="text"></label>
                        <label><span>正文</span><textarea id="mail_content"></textarea></label>
                        <label><span>命令，一行一个</span><textarea id="mail_commands"></textarea></label>
                        <label><span>过期时间戳 ms</span><input id="mail_expires" type="number" value="0"></label>
                        <button class="primary-button" type="submit">发送邮件</button>
                    </form>
                    <div class="divider"></div>
                    <div class="stack-form">
                        <label><span>快速给卡数量</span><input id="faction_amount" type="number" value="1" min="1"></label>
                        <div class="button-grid">
                            <button class="ghost-button faction-grant-button" type="button" data-faction="killer">杀手</button>
                            <button class="ghost-button faction-grant-button" type="button" data-faction="civilian">平民</button>
                            <button class="ghost-button faction-grant-button" type="button" data-faction="vigilante">警长</button>
                            <button class="ghost-button faction-grant-button" type="button" data-faction="neutral">中立</button>
                            <button class="ghost-button faction-grant-button" type="button" data-faction="neutral_for_killer">狼中立</button>
                        </div>
                    </div>
                </section>

                <section class="tool-panel">
                    <div class="panel-head tight-head">
                        <h2>全局邮件</h2>
                    </div>
                    <form id="global-mail-form" class="stack-form">
                        <label><span>发送者</span><input id="global_sender" type="text" value="System"></label>
                        <label><span>标题</span><input id="global_title" type="text"></label>
                        <label><span>正文</span><textarea id="global_content"></textarea></label>
                        <label><span>命令，一行一个</span><textarea id="global_commands"></textarea></label>
                        <label><span>过期时间戳 ms</span><input id="global_expires" type="number" value="0"></label>
                        <button class="primary-button" type="submit">创建全局邮件</button>
                    </form>
                </section>
            </aside>

            <section class="queue-panel">
                <div class="queue-column">
                    <div class="panel-head tight-head"><h2>待投递队列</h2></div>
                    <div id="pending-list" class="record-list"></div>
                </div>
                <div class="queue-column">
                    <div class="panel-head tight-head"><h2>全局邮件</h2></div>
                    <div id="global-mail-list" class="record-list"></div>
                </div>
            </section>
        </main>
    </div>

    <script src="./assets/admin.js"></script>
</body>
</html>
