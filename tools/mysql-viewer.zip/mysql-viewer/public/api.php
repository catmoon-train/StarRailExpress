<?php

declare(strict_types=1);

require __DIR__ . '/_app/bootstrap.php';

try {
    $action = viewer_query_string('action', 'summary');

    $loadZhLang = static function (): array {
        static $bundle = null;
        if ($bundle !== null) {
            return $bundle;
        }

        $bundle = [];
        $files = [
            __DIR__ . '/../src/main/resources/assets/starrailexpress/lang/zh_cn.json',
            __DIR__ . '/../src/main/resources/assets/stupid_express/lang/zh_cn.json',
            __DIR__ . '/../src/main/resources/assets/noellesroles/lang/zh_cn.json',
        ];
        foreach ($files as $file) {
            if (!is_file($file)) {
                continue;
            }
            $raw = file_get_contents($file);
            if (!is_string($raw) || trim($raw) === '') {
                continue;
            }
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $bundle = array_replace($bundle, $decoded);
            }
        }
        return $bundle;
    };

    $lang = static function (string $key, string $fallback = '') use ($loadZhLang): string {
        $bundle = $loadZhLang();
        if (isset($bundle[$key]) && is_string($bundle[$key]) && trim($bundle[$key]) !== '') {
            return $bundle[$key];
        }
        return $fallback !== '' ? $fallback : $key;
    };

    if ($action === 'logout') {
        viewer_logout();
        header('Location: ./login.php', true, 302);
        exit;
    }

    if ($action === 'login_status') {
        viewer_json_response([
            'ok' => true,
            'authenticated' => viewer_is_logged_in(),
        ]);
    }

    // player_dashboard is a public endpoint — no auth required
    if ($action === 'player_dashboard') {
        $identifier = viewer_query_string('identifier');
        if ($identifier === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier is required.'], 422);
        }

        $resolved = viewer_resolve_player($identifier);
        if (empty($resolved['player_uuid'])) {
            viewer_json_response(['ok' => false, 'message' => '未找到该玩家，请检查用户名是否正确。'], 404);
        }

        $records = viewer_fetch_player_records((string) $resolved['player_uuid']);
        $stats = isset($records['stats']['payload']) && is_array($records['stats']['payload']) ? $records['stats']['payload'] : [];
        $progression = isset($records['progression']['payload']) && is_array($records['progression']['payload']) ? $records['progression']['payload'] : [];
        $skins = isset($records['skins']['payload']) && is_array($records['skins']['payload']) ? $records['skins']['payload'] : [];
        $mailbox = isset($records['mailbox']['payload']) && is_array($records['mailbox']['payload']) ? $records['mailbox']['payload'] : [];

        $getNumber = static function (array $source, array $keys, int $default = 0): int {
            foreach ($keys as $key) {
                if (isset($source[$key]) && is_numeric($source[$key])) {
                    return (int) $source[$key];
                }
            }
            return $default;
        };

        $totalGames = $getNumber($stats, ['totalGamesPlayed'], 0);
        $totalWins = $getNumber($stats, ['totalWins'], 0);
        $totalKills = $getNumber($stats, ['totalKills'], 0);
        $totalDeaths = $getNumber($stats, ['totalDeaths'], 0);
        $winRate = $totalGames > 0 ? round(($totalWins / $totalGames) * 100, 1) : 0;
        $kd = $totalDeaths > 0 ? round($totalKills / $totalDeaths, 2) : ($totalKills > 0 ? (float) $totalKills : 0.0);

        $statsRows = [
            ['label' => '总游玩局数', 'value' => $totalGames],
            ['label' => '总胜场', 'value' => $totalWins],
            ['label' => '总败场', 'value' => $getNumber($stats, ['totalLosses'], 0)],
            ['label' => '总击杀', 'value' => $totalKills],
            ['label' => '总死亡', 'value' => $totalDeaths],
            ['label' => '误伤次数', 'value' => $getNumber($stats, ['totalTeamKills'], 0)],
            ['label' => '恋人模式胜场', 'value' => $getNumber($stats, ['totalLoversWins'], 0)],
            ['label' => '累计在线时长(秒)', 'value' => $getNumber($stats, ['totalPlayTime'], 0)],
            ['label' => '胜率', 'value' => $winRate . '%'],
            ['label' => 'K/D', 'value' => $kd],
        ];

        $factionRows = [
            [
                'faction' => $lang('sre.pass.faction.civilian', '平民阵营卡'),
                'games' => $getNumber($stats, ['totalCivilianGames'], 0),
                'wins' => $getNumber($stats, ['totalCivilianWins'], 0),
                'kills' => $getNumber($stats, ['totalCivilianKills'], 0),
                'deaths' => $getNumber($stats, ['totalCivilianDeaths'], 0),
            ],
            [
                'faction' => $lang('sre.pass.faction.killer', '杀手阵营卡'),
                'games' => $getNumber($stats, ['totalKillerGames'], 0),
                'wins' => $getNumber($stats, ['totalKillerWins'], 0),
                'kills' => $getNumber($stats, ['totalKillerKills'], 0),
                'deaths' => $getNumber($stats, ['totalKillerDeaths'], 0),
            ],
            [
                'faction' => $lang('sre.pass.faction.neutral', '中立阵营卡'),
                'games' => $getNumber($stats, ['totalNeutralGames'], 0),
                'wins' => $getNumber($stats, ['totalNeutralWins'], 0),
                'kills' => $getNumber($stats, ['totalNeutralKills'], 0),
                'deaths' => $getNumber($stats, ['totalNeutralDeaths'], 0),
            ],
            [
                'faction' => $lang('announcement.star.role.vigilante', '义警'),
                'games' => $getNumber($stats, ['totalSheriffGames'], 0),
                'wins' => $getNumber($stats, ['totalSheriffWins'], 0),
                'kills' => $getNumber($stats, ['totalSheriffKills'], 0),
                'deaths' => $getNumber($stats, ['totalSheriffDeaths'], 0),
            ],
        ];

        $level = $getNumber($progression, ['level', 'lv'], 1);
        $experience = $getNumber($progression, ['experience', 'xp'], 0);
        $totalExperience = $getNumber($progression, ['totalExperience', 'txp'], 0);
        $claimedCoinRewards = $getNumber($progression, ['claimedCoinRewards', 'ccr'], 0);
        $claimedLootRewards = $getNumber($progression, ['claimedLootRewards', 'clr'], 0);

        $progressRows = [
            ['label' => '当前等级', 'value' => $level],
            ['label' => '当前经验', 'value' => $experience],
            ['label' => '累计经验', 'value' => $totalExperience],
            ['label' => '已领取金币奖励', 'value' => $claimedCoinRewards],
            ['label' => '已领取抽卡奖励', 'value' => $claimedLootRewards],
        ];

        $factionCards = [];
        $cardRaw = $progression['factionCards'] ?? $progression['fc'] ?? [];
        if (is_array($cardRaw)) {
            $cardNameMap = [
                'killer' => $lang('sre.pass.faction.killer', '杀手阵营卡'),
                'civilian' => $lang('sre.pass.faction.civilian', '平民阵营卡'),
                'vigilante' => $lang('announcement.star.role.vigilante', '义警'),
                'neutral' => $lang('sre.pass.faction.neutral', '中立阵营卡'),
                'neutral_for_killer' => $lang('sre.pass.faction.neutral_for_killer', '杀手中立阵营卡'),
            ];
            foreach ($cardRaw as $key => $count) {
                if (!is_numeric($count)) {
                    continue;
                }
                $keyStr = is_string($key) ? strtolower($key) : (string) $key;
                $factionCards[] = [
                    'name' => $cardNameMap[$keyStr] ?? $keyStr,
                    'count' => (int) $count,
                ];
            }
        }

        $equipped = isset($skins['equipped']) && is_array($skins['equipped']) ? $skins['equipped'] : [];
        $unlocked = isset($skins['unlocked']) && is_array($skins['unlocked']) ? $skins['unlocked'] : [];
        $unlockedCount = 0;
        foreach ($unlocked as $group) {
            if (!is_array($group)) {
                continue;
            }
            foreach ($group as $flag) {
                if ($flag === true) {
                    $unlockedCount++;
                }
            }
        }
        $skinRows = [
            ['label' => '金币', 'value' => $getNumber($skins, ['coinNum'], 0)],
            ['label' => '抽奖机会', 'value' => $getNumber($skins, ['lootChance'], 0)],
            ['label' => '已装备皮肤数量', 'value' => count($equipped)],
            ['label' => '已解锁皮肤数量', 'value' => $unlockedCount],
        ];

        $mailTotal = 0;
        $mailUnread = 0;
        $mailClaimable = 0;
        $mailExpired = 0;
        foreach ($mailbox as $mail) {
            if (!is_array($mail)) {
                continue;
            }
            $mailTotal++;
            $read = isset($mail['read']) && $mail['read'] === true;
            $claimed = isset($mail['claimed']) && $mail['claimed'] === true;
            $expiresAt = isset($mail['expiresAt']) && is_numeric($mail['expiresAt']) ? (int) $mail['expiresAt'] : 0;
            $expired = $expiresAt > 0 && $expiresAt < (int) round(microtime(true) * 1000);
            if (!$read) {
                $mailUnread++;
            }
            if (!$claimed && !$expired) {
                $mailClaimable++;
            }
            if ($expired) {
                $mailExpired++;
            }
        }
        $mailRows = [
            ['label' => '总邮件数', 'value' => $mailTotal],
            ['label' => '未读邮件', 'value' => $mailUnread],
            ['label' => '可领取邮件', 'value' => $mailClaimable],
            ['label' => '已过期邮件', 'value' => $mailExpired],
        ];

        $roleRows = [];
        $roleStats = isset($stats['roleStats']) && is_array($stats['roleStats']) ? $stats['roleStats'] : [];
        foreach ($roleStats as $roleId => $row) {
            if (!is_array($row)) {
                continue;
            }
            $roleRows[] = [
                'role' => is_string($roleId) ? $roleId : 'unknown',
                'timesPlayed' => isset($row['timesPlayed']) && is_numeric($row['timesPlayed']) ? (int) $row['timesPlayed'] : 0,
                'winsAsRole' => isset($row['winsAsRole']) && is_numeric($row['winsAsRole']) ? (int) $row['winsAsRole'] : 0,
                'killsAsRole' => isset($row['killsAsRole']) && is_numeric($row['killsAsRole']) ? (int) $row['killsAsRole'] : 0,
                'deathsAsRole' => isset($row['deathsAsRole']) && is_numeric($row['deathsAsRole']) ? (int) $row['deathsAsRole'] : 0,
            ];
        }
        usort($roleRows, static fn(array $a, array $b): int => ($b['timesPlayed'] <=> $a['timesPlayed']));

        viewer_json_response([
            'ok' => true,
            'player' => [
                'identifier' => $resolved['identifier'] ?? $identifier,
                'username' => $resolved['player_name'] ?? $identifier,
                'uuid' => $resolved['player_uuid'] ?? null,
                'source' => $resolved['source'] ?? 'unknown',
            ],
            'dashboard' => [
                'statsRows' => $statsRows,
                'factionRows' => $factionRows,
                'progressRows' => $progressRows,
                'factionCards' => $factionCards,
                'skinRows' => $skinRows,
                'mailRows' => $mailRows,
                'roleRows' => array_slice($roleRows, 0, 30),
            ],
        ]);
    }

    viewer_require_auth_for_api();

    $requestBody = [];
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        $rawBody = file_get_contents('php://input');
        if (is_string($rawBody) && trim($rawBody) !== '') {
            $decodedBody = json_decode($rawBody, true);
            if (is_array($decodedBody)) {
                $requestBody = $decodedBody;
            }
        }
    }

    $pdo = viewer_pdo();
    $table = viewer_table_name();

    $bodyString = static function (string $key, string $default = '') use ($requestBody): string {
        $value = $requestBody[$key] ?? $default;
        return is_string($value) ? trim($value) : $default;
    };

    $bodyInt = static function (string $key, int $default = 0) use ($requestBody): int {
        $value = $requestBody[$key] ?? $default;
        return is_numeric($value) ? (int) $value : $default;
    };

    $bodyArray = static function (string $key) use ($requestBody): array {
        $value = $requestBody[$key] ?? [];
        return is_array($value) ? $value : [];
    };

    if ($action === 'admin_overview') {
        viewer_ensure_admin_schema();
        $tables = viewer_admin_table_names();
        $total = (int) $pdo->query("SELECT COUNT(*) FROM {$table}")->fetchColumn();
        $latest = $pdo->query("SELECT MAX(updated_at) FROM {$table}")->fetchColumn();
        $stmt = $pdo->query(
            "SELECT data_key, COUNT(*) AS record_count FROM {$table} GROUP BY data_key ORDER BY record_count DESC, data_key ASC"
        );
        $groups = $stmt->fetchAll();
        $usercache = viewer_load_usercache();
        $pendingCount = (int) $pdo->query('SELECT COUNT(*) FROM ' . $tables['pending_ops'] . " WHERE status = 'pending'")->fetchColumn();
        $globalMailCount = (int) $pdo->query('SELECT COUNT(*) FROM ' . $tables['global_mail'] . ' WHERE active = 1')->fetchColumn();

        viewer_json_response([
            'ok' => true,
            'overview' => [
                'summary' => [
                    'total_records' => $total,
                    'latest_updated_at' => $latest !== false ? (int) $latest : null,
                    'groups' => $groups,
                    'usercache_count' => count($usercache['entries']),
                    'pending_count' => $pendingCount,
                    'global_mail_count' => $globalMailCount,
                ],
                'pending' => viewer_list_pending_ops(20),
                'global_mails' => viewer_list_global_mails(20),
                'recent_players' => viewer_recent_players(viewer_config_int('recent_player_limit', 30, 1, 100)),
            ],
        ]);
    }

    if ($action === 'refresh_player_index') {
        viewer_json_response([
            'ok' => true,
            'refresh' => viewer_refresh_player_index(),
        ]);
    }

    if ($action === 'ensure_indexes') {
        viewer_json_response([
            'ok' => true,
            'indexes' => viewer_try_ensure_performance_indexes(),
        ]);
    }

    if ($action === 'summary') {
        $total = (int) $pdo->query("SELECT COUNT(*) FROM {$table}")->fetchColumn();
        $latest = $pdo->query("SELECT MAX(updated_at) FROM {$table}")->fetchColumn();
        $stmt = $pdo->query(
            "SELECT data_key, COUNT(*) AS record_count FROM {$table} GROUP BY data_key ORDER BY record_count DESC, data_key ASC"
        );
        $groups = $stmt->fetchAll();

        viewer_json_response([
            'ok' => true,
            'summary' => [
                'total_records' => $total,
                'latest_updated_at' => $latest !== false ? (int) $latest : null,
                'groups' => $groups,
            ],
        ]);
    }

    if ($action === 'records') {
        $config = viewer_config();
        $pageSize = max(1, min(
            viewer_query_int('page_size', (int) $config['default_page_size']),
            (int) $config['max_page_size']
        ));
        $page = max(1, viewer_query_int('page', 1));
        $player = viewer_query_string('player_uuid');
        $dataKey = viewer_query_string('data_key');

        $where = [];
        $params = [];

        if ($player !== '') {
            $where[] = 'player_uuid = :player_uuid';
            $params['player_uuid'] = $player;
        }
        if ($dataKey !== '') {
            $where[] = 'data_key = :data_key';
            $params['data_key'] = $dataKey;
        }

        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

        $countSql = "SELECT COUNT(*) FROM {$table} {$whereSql}";
        $countStmt = $pdo->prepare($countSql);
        foreach ($params as $key => $value) {
            $countStmt->bindValue(':' . $key, $value);
        }
        $countStmt->execute();
        $total = (int) $countStmt->fetchColumn();

        $offset = ($page - 1) * $pageSize;
        $sql = "SELECT player_uuid, data_key, payload_json, updated_at FROM {$table} {$whereSql} ORDER BY updated_at DESC LIMIT :limit OFFSET :offset";
        $stmt = $pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        $stmt->bindValue(':limit', $pageSize, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        $records = array_map(static function (array $row): array {
            return [
                'player_uuid' => $row['player_uuid'],
                'data_key' => $row['data_key'],
                'updated_at' => (int) $row['updated_at'],
                'preview' => viewer_payload_preview($row['payload_json']),
            ];
        }, $stmt->fetchAll());

        viewer_json_response([
            'ok' => true,
            'records' => $records,
            'pagination' => [
                'page' => $page,
                'page_size' => $pageSize,
                'total' => $total,
                'total_pages' => max(1, (int) ceil($total / $pageSize)),
            ],
        ]);
    }

    if ($action === 'record') {
        $player = viewer_query_string('player_uuid');
        $dataKey = viewer_query_string('data_key');

        if ($player === '' || $dataKey === '') {
            viewer_json_response([
                'ok' => false,
                'message' => 'player_uuid and data_key are required.',
            ], 422);
        }

        $stmt = $pdo->prepare(
            "SELECT player_uuid, data_key, payload_json, updated_at FROM {$table} WHERE player_uuid = :player_uuid AND data_key = :data_key LIMIT 1"
        );
        $stmt->execute([
            'player_uuid' => $player,
            'data_key' => $dataKey,
        ]);
        $record = $stmt->fetch();

        if (!$record) {
            viewer_json_response([
                'ok' => false,
                'message' => 'Record not found.',
            ], 404);
        }

        viewer_json_response([
            'ok' => true,
            'record' => [
                'player_uuid' => $record['player_uuid'],
                'data_key' => $record['data_key'],
                'updated_at' => (int) $record['updated_at'],
                'payload' => viewer_decode_payload($record['payload_json']),
                'raw_payload' => $record['payload_json'],
            ],
        ]);
    }

    if ($action === 'profile') {
        viewer_ensure_admin_schema();
        $identifier = viewer_query_string('identifier');
        $resolved = viewer_resolve_player($identifier);
        $records = [];
        if (!empty($resolved['player_uuid'])) {
            $records = viewer_fetch_player_records($resolved['player_uuid']);
        }

        $tables = viewer_admin_table_names();
        $sql = 'SELECT * FROM ' . $tables['pending_ops'] . ' WHERE player_name = :player_name';
        if (!empty($resolved['player_uuid'])) {
            $sql .= ' OR player_uuid = :player_uuid';
        }
        $sql .= ' ORDER BY created_at DESC LIMIT 50';
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':player_name', $resolved['player_name']);
        if (!empty($resolved['player_uuid'])) {
            $stmt->bindValue(':player_uuid', $resolved['player_uuid']);
        }
        $stmt->execute();

        viewer_json_response([
            'ok' => true,
            'profile' => [
                'player' => $resolved,
                'records' => $records,
                'pending' => $stmt->fetchAll(),
            ],
        ]);
    }

    if ($action === 'save_raw') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        $dataKey = $bodyString('data_key');
        $rawPayload = $bodyString('raw_payload');
        if ($identifier === '' || $dataKey === '' || $rawPayload === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier, data_key and raw_payload are required.'], 422);
        }

        json_decode($rawPayload, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            viewer_json_response(['ok' => false, 'message' => 'raw_payload must be valid JSON.'], 422);
        }

        $resolved = viewer_resolve_player($identifier);
        if (!empty($resolved['player_uuid'])) {
            viewer_upsert_sync_record($resolved['player_uuid'], $dataKey, $rawPayload);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, $dataKey, 'raw_replace', [
            'raw_payload' => $rawPayload,
        ], 'Queued by raw editor');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'save_skins') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        if ($identifier === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier is required.'], 422);
        }

        $patch = [
            'coinNum' => $bodyInt('coinNum', 0),
            'lootChance' => $bodyInt('lootChance', 0),
            'equipped' => $bodyArray('equipped'),
            'unlocked' => $bodyArray('unlocked'),
        ];

        $resolved = viewer_resolve_player($identifier);
        if (!empty($resolved['player_uuid'])) {
            $existing = viewer_fetch_sync_record($resolved['player_uuid'], 'skins');
            $merged = viewer_merge_skins_payload($existing['payload_json'] ?? null, $patch);
            viewer_upsert_sync_record($resolved['player_uuid'], 'skins', $merged);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'skins', 'skins_merge', $patch, 'Queued skin update');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'save_progression') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        if ($identifier === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier is required.'], 422);
        }

        $patch = [
            'level' => $bodyInt('level', 1),
            'experience' => $bodyInt('experience', 0),
            'totalExperience' => $bodyInt('totalExperience', 0),
            'claimedCoinRewards' => $bodyInt('claimedCoinRewards', 0),
            'claimedLootRewards' => $bodyInt('claimedLootRewards', 0),
            'lastQuestRefreshTime' => $bodyInt('lastQuestRefreshTime', 0),
            'lastWeeklyRefreshTime' => $bodyInt('lastWeeklyRefreshTime', 0),
            'factionCards' => $bodyArray('factionCards'),
        ];

        $resolved = viewer_resolve_player($identifier);
        if (!empty($resolved['player_uuid'])) {
            $existing = viewer_fetch_sync_record($resolved['player_uuid'], 'progression');
            $merged = viewer_merge_progression_payload($existing['payload_json'] ?? null, $patch);
            viewer_upsert_sync_record($resolved['player_uuid'], 'progression', $merged);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'progression', 'progression_merge', $patch, 'Queued progression update');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'save_stats') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        if ($identifier === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier is required.'], 422);
        }

        $fields = [
            'totalPlayTime',
            'totalGamesPlayed',
            'totalKills',
            'totalDeaths',
            'totalWins',
            'totalLosses',
            'totalTeamKills',
            'totalLoversWins',
            'totalCivilianGames',
            'totalCivilianWins',
            'totalCivilianKills',
            'totalCivilianDeaths',
            'totalKillerGames',
            'totalKillerWins',
            'totalKillerKills',
            'totalKillerDeaths',
            'totalNeutralGames',
            'totalNeutralWins',
            'totalNeutralKills',
            'totalNeutralDeaths',
            'totalSheriffGames',
            'totalSheriffWins',
            'totalSheriffKills',
            'totalSheriffDeaths',
        ];
        $patch = [];
        foreach ($fields as $field) {
            $patch[$field] = $bodyInt($field, 0);
        }
        $patch['roleStats'] = $bodyArray('roleStats');

        $resolved = viewer_resolve_player($identifier);
        if (!empty($resolved['player_uuid'])) {
            $existing = viewer_fetch_sync_record($resolved['player_uuid'], 'stats');
            $merged = viewer_merge_stats_payload($existing['payload_json'] ?? null, $patch);
            viewer_upsert_sync_record($resolved['player_uuid'], 'stats', $merged);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'stats', 'stats_merge', $patch, 'Queued stats update');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'save_mailbox') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        if ($identifier === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier is required.'], 422);
        }
        $patch = [
            'mails' => $bodyArray('mails'),
        ];

        $resolved = viewer_resolve_player($identifier);
        if (!empty($resolved['player_uuid'])) {
            $merged = viewer_replace_mailbox_payload($patch['mails']);
            viewer_upsert_sync_record($resolved['player_uuid'], 'mailbox', $merged);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'mailbox', 'mailbox_replace', $patch, 'Queued mailbox replacement');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'save_nametags') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        if ($identifier === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier is required.'], 422);
        }
        $patch = [
            'nameTags' => $bodyArray('nameTags'),
            'currentNametag' => $bodyString('currentNametag'),
        ];

        $resolved = viewer_resolve_player($identifier);
        if (!empty($resolved['player_uuid'])) {
            $existing = viewer_fetch_sync_record($resolved['player_uuid'], 'nametags');
            $merged = viewer_merge_nametags_payload($existing['payload_json'] ?? null, $patch);
            viewer_upsert_sync_record($resolved['player_uuid'], 'nametags', $merged);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'nametags', 'nametags_merge', $patch, 'Queued nametag update');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'send_mail') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('recipient', $bodyString('identifier'));
        $title = $bodyString('title');
        if ($identifier === '' || $title === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier and title are required.'], 422);
        }

        $recipients = viewer_split_identifiers($identifier);
        if ($recipients === []) {
            viewer_json_response(['ok' => false, 'message' => 'No valid recipients found.'], 422);
        }

        $results = [];
        $appliedCount = 0;
        $queuedCount = 0;

        foreach ($recipients as $recipient) {
            $mail = viewer_build_mail_payload(
                $bodyString('sender', 'System'),
                $title,
                $bodyString('content'),
                $bodyArray('commands'),
                $bodyInt('expiresAt', 0)
            );

            $resolved = viewer_resolve_player($recipient);
            if (!empty($resolved['player_uuid'])) {
                $existing = viewer_fetch_sync_record($resolved['player_uuid'], 'mailbox');
                $merged = viewer_merge_mailbox_payload($existing['payload_json'] ?? null, [$mail]);
                viewer_upsert_sync_record($resolved['player_uuid'], 'mailbox', $merged);
                $results[] = [
                    'recipient' => $recipient,
                    'mode' => 'applied',
                    'player' => $resolved,
                    'mail' => $mail,
                ];
                $appliedCount++;
                continue;
            }

            $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'mailbox', 'mailbox_append', [
                'mails' => [$mail],
            ], 'Queued mailbox delivery');
            $results[] = [
                'recipient' => $recipient,
                'mode' => 'queued',
                'pending_id' => $pendingId,
                'player' => $resolved,
                'mail' => $mail,
            ];
            $queuedCount++;
        }

        viewer_json_response([
            'ok' => true,
            'mode' => count($recipients) === 1 ? $results[0]['mode'] : 'batch',
            'player' => count($recipients) === 1 ? ($results[0]['player'] ?? null) : null,
            'mail' => count($recipients) === 1 ? ($results[0]['mail'] ?? null) : null,
            'pending_id' => count($recipients) === 1 ? ($results[0]['pending_id'] ?? null) : null,
            'results' => $results,
            'summary' => [
                'total' => count($recipients),
                'applied' => $appliedCount,
                'queued' => $queuedCount,
            ],
        ]);
    }

    if ($action === 'grant_faction_card') {
        viewer_ensure_admin_schema();
        $identifier = $bodyString('identifier');
        $faction = strtolower($bodyString('faction'));
        $amount = max(1, $bodyInt('amount', 1));
        if ($identifier === '' || $faction === '') {
            viewer_json_response(['ok' => false, 'message' => 'identifier and faction are required.'], 422);
        }

        $allowed = ['killer', 'civilian', 'vigilante', 'neutral', 'neutral_for_killer'];
        if (!in_array($faction, $allowed, true)) {
            viewer_json_response(['ok' => false, 'message' => 'invalid faction.'], 422);
        }

        $resolved = viewer_resolve_player($identifier);
        $patch = [
            'factionCardsDelta' => [
                $faction => $amount,
            ],
        ];

        if (!empty($resolved['player_uuid'])) {
            $existing = viewer_fetch_sync_record($resolved['player_uuid'], 'progression');
            $merged = viewer_merge_progression_payload($existing['payload_json'] ?? null, $patch);
            viewer_upsert_sync_record($resolved['player_uuid'], 'progression', $merged);
            viewer_json_response(['ok' => true, 'mode' => 'applied', 'player' => $resolved]);
        }

        $pendingId = viewer_queue_pending_op($resolved['player_name'], null, 'progression', 'progression_merge', $patch, 'Queued faction card grant');
        viewer_json_response(['ok' => true, 'mode' => 'queued', 'pending_id' => $pendingId, 'player' => $resolved]);
    }

    if ($action === 'create_global_mail') {
        viewer_ensure_admin_schema();
        $title = $bodyString('title');
        if ($title === '') {
            viewer_json_response(['ok' => false, 'message' => 'title is required.'], 422);
        }

        $mail = viewer_build_mail_payload(
            $bodyString('sender', 'System'),
            $title,
            $bodyString('content'),
            $bodyArray('commands'),
            $bodyInt('expiresAt', 0)
        );
        viewer_insert_global_mail($mail);
        viewer_json_response([
            'ok' => true,
            'mail' => $mail,
        ]);
    }

    if ($action === 'reconcile') {
        viewer_ensure_admin_schema();
        viewer_json_response([
            'ok' => true,
            'reconcile' => viewer_run_reconcile(),
        ]);
    }

    if ($action === 'pending') {
        viewer_ensure_admin_schema();
        viewer_json_response([
            'ok' => true,
            'pending' => viewer_list_pending_ops(100),
        ]);
    }

    viewer_json_response([
        'ok' => false,
        'message' => 'Unknown action.',
    ], 404);
} catch (Throwable $throwable) {
    viewer_json_response([
        'ok' => false,
        'message' => $throwable->getMessage(),
    ], 500);
}
