<?php

return [
    'site_title' => 'StarRailExpress Sync Viewer',
    'auth' => [
        'enabled' => true,
        'username' => 'admin',
        // 生产环境请改为 password_hash('你的密码', PASSWORD_DEFAULT) 的结果。
        'password_hash' => '',
        // 仅用于首次部署过渡，配置 password_hash 后可删除此项。
        'password_plain' => 'change_me_now',
        'session_name' => 'sre_viewer_session',
    ],
    'usercache_path' => '/www/server/minecraft/run/usercache.json',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => 'starrailexpress',
        'username' => 'viewer_readonly',
        'password' => 'replace_me',
        'charset' => 'utf8mb4',
    ],
    'table_name' => 'sre_player_sync_data',
    'default_page_size' => 25,
    'max_page_size' => 100,
    'identity_sync_batch_size' => 500,
    'reconcile_batch_size' => 500,
    'recent_player_limit' => 30,
];
