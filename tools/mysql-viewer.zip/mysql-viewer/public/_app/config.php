<?php

return [
    'site_title' => 'StarRailExpress Sync Viewer',
    'db' => [
        'host' => '47.100.247.184',
        'port' => 3306,
        'database' => 'train_data',
        'username' => 'train_data',
        'password' => 'zZ3fcAPYNpaNG6kX',
        'charset' => 'utf8mb4',
    ],
    'table_name' => 'sre_player_sync_data',
    'default_page_size' => 25,
    'max_page_size' => 100,
];