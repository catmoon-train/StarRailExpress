<?php

declare(strict_types=1);

function viewer_auth_config(): array
{
    $auth = viewer_config()['auth'] ?? [];
    if (!is_array($auth)) {
        $auth = [];
    }
    return [
        'enabled' => (bool) ($auth['enabled'] ?? true),
        'username' => (string) ($auth['username'] ?? 'admin'),
        'password_hash' => (string) ($auth['password_hash'] ?? ''),
        'password_plain' => (string) ($auth['password_plain'] ?? 'change_me_now'),
        'session_name' => (string) ($auth['session_name'] ?? 'sre_viewer_session'),
    ];
}

function viewer_start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    $auth = viewer_auth_config();
    session_name($auth['session_name']);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function viewer_is_logged_in(): bool
{
    $auth = viewer_auth_config();
    if (!$auth['enabled']) {
        return true;
    }

    viewer_start_session();
    return isset($_SESSION['viewer_auth_ok']) && $_SESSION['viewer_auth_ok'] === true;
}

function viewer_verify_login(string $username, string $password): bool
{
    $auth = viewer_auth_config();
    if (!$auth['enabled']) {
        return true;
    }

    if ($auth['username'] === '' || !hash_equals($auth['username'], $username)) {
        return false;
    }

    $hash = trim($auth['password_hash']);
    if ($hash !== '') {
        return password_verify($password, $hash);
    }

    $plain = (string) $auth['password_plain'];
    if ($plain === '') {
        return false;
    }
    return hash_equals($plain, $password);
}

function viewer_login(string $username): void
{
    viewer_start_session();
    session_regenerate_id(true);
    $_SESSION['viewer_auth_ok'] = true;
    $_SESSION['viewer_auth_user'] = $username;
    $_SESSION['viewer_auth_at'] = time();
}

function viewer_logout(): void
{
    viewer_start_session();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $params['path'], $params['domain'] ?? '', (bool) $params['secure'], (bool) $params['httponly']);
    }
    session_destroy();
}

function viewer_require_auth_for_page(): void
{
    if (viewer_is_logged_in()) {
        return;
    }
    $path = $_SERVER['REQUEST_URI'] ?? '/';
    $target = './login.php?next=' . rawurlencode($path);
    header('Location: ' . $target, true, 302);
    exit;
}

function viewer_require_auth_for_api(): void
{
    if (viewer_is_logged_in()) {
        return;
    }
    viewer_json_response([
        'ok' => false,
        'message' => 'Unauthorized. Please login first.',
    ], 401);
}

function viewer_config(): array
{
    static $config = null;

    if ($config !== null) {
        return $config;
    }

    $configFile = __DIR__ . '/config.php';
    $sampleFile = __DIR__ . '/config.sample.php';

    if (is_file($configFile)) {
        $loaded = require $configFile;
    } else {
        $loaded = require $sampleFile;
    }

    if (!is_array($loaded)) {
        throw new RuntimeException('Invalid viewer config.');
    }

    $config = $loaded;
    return $config;
}

function viewer_pdo(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $config = viewer_config();
    $db = $config['db'];
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $db['host'],
        (int) $db['port'],
        $db['database'],
        $db['charset']
    );

    $pdo = new PDO($dsn, $db['username'], $db['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}

function viewer_table_name(): string
{
    $table = (string) (viewer_config()['table_name'] ?? 'sre_player_sync_data');
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) {
        throw new RuntimeException('Invalid table name.');
    }
    return $table;
}

function viewer_json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function viewer_query_string(string $key, string $default = ''): string
{
    $value = $_GET[$key] ?? $default;
    return is_string($value) ? trim($value) : $default;
}

function viewer_query_int(string $key, int $default): int
{
    $raw = $_GET[$key] ?? $default;
    if (is_numeric($raw)) {
        return (int) $raw;
    }
    return $default;
}

function viewer_split_identifiers(string $raw): array
{
    $raw = trim($raw);
    if ($raw === '') {
        return [];
    }

    $parts = preg_split('/[\s,，;；\|]+/u', $raw) ?: [];
    $unique = [];
    foreach ($parts as $part) {
        if (!is_string($part)) {
            continue;
        }
        $identifier = trim($part);
        if ($identifier === '') {
            continue;
        }
        $unique[strtolower($identifier)] = $identifier;
    }
    return array_values($unique);
}

function viewer_decode_payload(?string $payload): mixed
{
    if ($payload === null || $payload === '') {
        return null;
    }

    try {
        return json_decode($payload, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        return $payload;
    }
}

function viewer_payload_preview(?string $payload, int $limit = 140): string
{
    if ($payload === null) {
        return '';
    }

    $flat = preg_replace('/\s+/u', ' ', trim($payload));
    if ($flat === null) {
        $flat = trim($payload);
    }

    if (mb_strlen($flat) <= $limit) {
        return $flat;
    }

    return mb_substr($flat, 0, $limit - 1) . '…';
}

function viewer_admin_table_names(): array
{
    $syncTable = viewer_table_name();
    $suffix = 'player_sync_data';
    $prefix = str_ends_with($syncTable, $suffix) ? substr($syncTable, 0, -strlen($suffix)) : 'sre_';

    return [
        'pending_ops' => $prefix . 'admin_pending_ops',
        'global_mail' => $prefix . 'admin_global_mail',
        'global_mail_delivery' => $prefix . 'admin_global_mail_delivery',
        'player_index' => $prefix . 'admin_player_index',
    ];
}

function viewer_config_int(string $key, int $default, int $min = 1, int $max = PHP_INT_MAX): int
{
    $value = viewer_config()[$key] ?? $default;
    if (!is_numeric($value)) {
        return $default;
    }
    return max($min, min((int) $value, $max));
}

function viewer_ensure_admin_schema(): void
{
    static $schemaReady = false;
    if ($schemaReady) {
        return;
    }

    $pdo = viewer_pdo();
    $tables = viewer_admin_table_names();
    $pendingTable = $tables['pending_ops'];
    $globalMailTable = $tables['global_mail'];
    $globalMailDeliveryTable = $tables['global_mail_delivery'];
    $playerIndexTable = $tables['player_index'];

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS {$pendingTable} ("
        . "id BIGINT NOT NULL AUTO_INCREMENT,"
        . "player_name VARCHAR(64) NOT NULL,"
        . "player_uuid CHAR(36) NULL,"
        . "data_key VARCHAR(64) NOT NULL,"
        . "operation_type VARCHAR(32) NOT NULL,"
        . "payload_json LONGTEXT NOT NULL,"
        . "status VARCHAR(16) NOT NULL DEFAULT 'pending',"
        . "note VARCHAR(255) NULL,"
        . "created_at BIGINT NOT NULL,"
        . "updated_at BIGINT NOT NULL,"
        . "applied_at BIGINT NULL,"
        . "PRIMARY KEY (id),"
        . "KEY idx_status (status),"
        . "KEY idx_player_name (player_name),"
        . "KEY idx_player_uuid (player_uuid),"
        . "KEY idx_data_key (data_key)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS {$globalMailTable} ("
        . "id CHAR(36) NOT NULL,"
        . "sender VARCHAR(64) NOT NULL,"
        . "title VARCHAR(255) NOT NULL,"
        . "content LONGTEXT NOT NULL,"
        . "commands_json LONGTEXT NOT NULL,"
        . "sent_at BIGINT NOT NULL,"
        . "expires_at BIGINT NOT NULL,"
        . "active TINYINT(1) NOT NULL DEFAULT 1,"
        . "created_at BIGINT NOT NULL,"
        . "updated_at BIGINT NOT NULL,"
        . "PRIMARY KEY (id),"
        . "KEY idx_active (active),"
        . "KEY idx_sent_at (sent_at)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS {$globalMailDeliveryTable} ("
        . "mail_id CHAR(36) NOT NULL,"
        . "player_uuid CHAR(36) NOT NULL,"
        . "delivered_at BIGINT NOT NULL,"
        . "PRIMARY KEY (mail_id, player_uuid),"
        . "KEY idx_player_uuid (player_uuid),"
        . "KEY idx_delivered_at (delivered_at)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS {$playerIndexTable} ("
        . "player_uuid CHAR(36) NOT NULL,"
        . "player_name VARCHAR(64) NOT NULL,"
        . "name_key VARCHAR(64) NOT NULL,"
        . "source VARCHAR(32) NOT NULL,"
        . "last_seen_at BIGINT NOT NULL,"
        . "updated_at BIGINT NOT NULL,"
        . "PRIMARY KEY (player_uuid),"
        . "UNIQUE KEY uniq_name_key (name_key),"
        . "KEY idx_last_seen_at (last_seen_at)"
        . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $schemaReady = true;
}

function viewer_try_ensure_performance_indexes(): array
{
    static $result = null;
    if ($result !== null) {
        return $result;
    }

    $result = [
        'attempted' => true,
        'created' => [],
        'skipped' => [],
    ];

    $pdo = viewer_pdo();
    $table = viewer_table_name();
    $indexes = [
        'idx_data_key_updated_at' => 'ALTER TABLE ' . $table . ' ADD INDEX idx_data_key_updated_at (data_key, updated_at)',
        'idx_player_uuid_updated_at' => 'ALTER TABLE ' . $table . ' ADD INDEX idx_player_uuid_updated_at (player_uuid, updated_at)',
    ];

    foreach ($indexes as $name => $sql) {
        try {
            $pdo->exec($sql);
            $result['created'][] = $name;
        } catch (PDOException $exception) {
            $message = $exception->getMessage();
            if (strpos($message, 'Duplicate key name') !== false || strpos($message, 'already exists') !== false) {
                $result['skipped'][] = $name . ': exists';
            } else {
                $result['skipped'][] = $name . ': ' . $message;
            }
        }
    }

    return $result;
}

function viewer_usercache_path(): string
{
    return (string) (viewer_config()['usercache_path'] ?? '');
}

function viewer_load_usercache(): array
{
    static $cache = null;

    if ($cache !== null) {
        return $cache;
    }

    $path = viewer_usercache_path();
    $result = [
        'entries' => [],
        'by_name' => [],
        'by_uuid' => [],
    ];

    if ($path === '' || !is_file($path)) {
        $cache = $result;
        return $cache;
    }

    $raw = file_get_contents($path);
    if ($raw === false || $raw === '') {
        $cache = $result;
        return $cache;
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        $cache = $result;
        return $cache;
    }

    foreach ($decoded as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $name = isset($entry['name']) && is_string($entry['name']) ? trim($entry['name']) : '';
        $uuid = isset($entry['uuid']) && is_string($entry['uuid']) ? trim($entry['uuid']) : '';
        if ($name === '' || $uuid === '') {
            continue;
        }
        $record = [
            'name' => $name,
            'uuid' => $uuid,
            'expiresOn' => isset($entry['expiresOn']) && is_string($entry['expiresOn']) ? $entry['expiresOn'] : '',
        ];
        $result['entries'][] = $record;
        $result['by_name'][strtolower($name)] = $record;
        $result['by_uuid'][strtolower($uuid)] = $record;
    }

    $cache = $result;
    return $cache;
}

function viewer_is_uuid(string $value): bool
{
    return preg_match('/^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}$/', $value) === 1;
}

function viewer_upsert_player_index(string $playerName, string $playerUuid, string $source = 'usercache', ?int $seenAt = null): void
{
    $playerName = trim($playerName);
    $playerUuid = trim($playerUuid);
    $nameKey = strtolower($playerName);
    if ($playerName === '' || $playerUuid === '' || !viewer_is_uuid($playerUuid)) {
        return;
    }

    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $now = $seenAt ?? (int) round(microtime(true) * 1000);
    $pdo = viewer_pdo();

    $pdo->beginTransaction();
    try {
        $existingLastSeen = 0;
        $lookupStmt = $pdo->prepare(
            'SELECT last_seen_at FROM ' . $tables['player_index']
            . ' WHERE player_uuid = :player_uuid OR name_key = :name_key'
        );
        $lookupStmt->execute([
            'player_uuid' => $playerUuid,
            'name_key' => $nameKey,
        ]);
        foreach ($lookupStmt->fetchAll() as $row) {
            if (isset($row['last_seen_at']) && is_numeric($row['last_seen_at'])) {
                $existingLastSeen = max($existingLastSeen, (int) $row['last_seen_at']);
            }
        }

        $deleteStmt = $pdo->prepare(
            'DELETE FROM ' . $tables['player_index']
            . ' WHERE player_uuid = :player_uuid OR name_key = :name_key'
        );
        $deleteStmt->execute([
            'player_uuid' => $playerUuid,
            'name_key' => $nameKey,
        ]);

        $insertStmt = $pdo->prepare(
            'INSERT INTO ' . $tables['player_index']
            . ' (player_uuid, player_name, name_key, source, last_seen_at, updated_at)'
            . ' VALUES (:player_uuid, :player_name, :name_key, :source, :last_seen_at, :updated_at)'
        );
        $insertStmt->execute([
            'player_uuid' => $playerUuid,
            'player_name' => $playerName,
            'name_key' => $nameKey,
            'source' => $source,
            'last_seen_at' => max($existingLastSeen, $now),
            'updated_at' => $now,
        ]);
        $pdo->commit();
    } catch (Throwable $throwable) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $throwable;
    }
}

function viewer_sync_player_index_from_usercache(): array
{
    $report = [
        'source' => 'usercache',
        'processed' => 0,
        'indexed' => 0,
        'skipped' => 0,
    ];

    foreach (viewer_load_usercache()['entries'] as $entry) {
        $report['processed']++;
        if (!isset($entry['name'], $entry['uuid'])) {
            $report['skipped']++;
            continue;
        }
        viewer_upsert_player_index((string) $entry['name'], (string) $entry['uuid'], 'usercache');
        $report['indexed']++;
    }

    return $report;
}

function viewer_extract_player_identity(?string $payloadJson, ?string $fallbackUuid = null): ?array
{
    if ($payloadJson === null || trim($payloadJson) === '') {
        return null;
    }

    $decoded = json_decode($payloadJson, true);
    if (!is_array($decoded)) {
        return null;
    }

    $playerUuid = '';
    $playerName = '';

    foreach (['uuid', 'player_uuid', 'playerUuid'] as $uuidKey) {
        if (isset($decoded[$uuidKey]) && is_string($decoded[$uuidKey])) {
            $playerUuid = trim($decoded[$uuidKey]);
            if ($playerUuid !== '') {
                break;
            }
        }
    }
    if ($playerUuid === '' && $fallbackUuid !== null) {
        $playerUuid = trim($fallbackUuid);
    }

    foreach (['username', 'name', 'player_name', 'playerName'] as $nameKey) {
        if (isset($decoded[$nameKey]) && is_string($decoded[$nameKey])) {
            $playerName = trim($decoded[$nameKey]);
            if ($playerName !== '') {
                break;
            }
        }
    }

    if ($playerName === '' || !viewer_is_uuid($playerUuid)) {
        return null;
    }

    return [
        'player_name' => $playerName,
        'player_uuid' => $playerUuid,
    ];
}

function viewer_sync_player_index_from_sync_table(?int $limit = null, int $offset = 0): array
{
    $limit = $limit ?? viewer_config_int('identity_sync_batch_size', 500, 1, 5000);
    $offset = max(0, $offset);
    $report = [
        'source' => 'sync_table',
        'processed' => 0,
        'indexed' => 0,
        'skipped' => 0,
        'limit' => $limit,
        'offset' => $offset,
    ];

    $stmt = viewer_pdo()->prepare(
        'SELECT player_uuid, payload_json, updated_at FROM ' . viewer_table_name()
        . ' WHERE data_key = :data_key ORDER BY updated_at DESC LIMIT :limit OFFSET :offset'
    );
    $stmt->bindValue(':data_key', 'player_identity');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $rows = array_reverse($stmt->fetchAll());
    foreach ($rows as $row) {
        $report['processed']++;
        $identity = viewer_extract_player_identity(
            isset($row['payload_json']) && is_string($row['payload_json']) ? $row['payload_json'] : null,
            isset($row['player_uuid']) && is_string($row['player_uuid']) ? $row['player_uuid'] : null
        );
        if ($identity === null) {
            $report['skipped']++;
            continue;
        }
        viewer_upsert_player_index(
            $identity['player_name'],
            $identity['player_uuid'],
            'sync_table',
            isset($row['updated_at']) ? (int) $row['updated_at'] : null
        );
        $report['indexed']++;
    }

    return $report;
}

function viewer_refresh_player_index(): array
{
    viewer_ensure_admin_schema();
    return [
        'usercache' => viewer_sync_player_index_from_usercache(),
        'sync_table' => viewer_sync_player_index_from_sync_table(),
    ];
}

function viewer_lookup_player_index_by_name(string $playerName): ?array
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('SELECT player_uuid, player_name, source, last_seen_at FROM ' . $tables['player_index'] . ' WHERE name_key = :name_key LIMIT 1');
    $stmt->execute([
        'name_key' => strtolower(trim($playerName)),
    ]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function viewer_lookup_player_index_by_uuid(string $playerUuid): ?array
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('SELECT player_uuid, player_name, source, last_seen_at FROM ' . $tables['player_index'] . ' WHERE player_uuid = :player_uuid LIMIT 1');
    $stmt->execute([
        'player_uuid' => trim($playerUuid),
    ]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function viewer_find_player_identity_in_sync_table(string $identifier): ?array
{
    $identifier = trim($identifier);
    if ($identifier === '') {
        return null;
    }

    if (viewer_is_uuid($identifier)) {
        $stmt = viewer_pdo()->prepare(
            'SELECT player_uuid, payload_json, updated_at FROM ' . viewer_table_name()
            . ' WHERE data_key = :data_key AND player_uuid = :player_uuid ORDER BY updated_at DESC LIMIT 1'
        );
        $stmt->execute([
            'data_key' => 'player_identity',
            'player_uuid' => $identifier,
        ]);
    } else {
        $stmt = viewer_pdo()->prepare(
            'SELECT player_uuid, payload_json, updated_at FROM ' . viewer_table_name()
            . ' WHERE data_key = :data_key AND payload_json LIKE :username_like ORDER BY updated_at DESC LIMIT 5'
        );
        $stmt->execute([
            'data_key' => 'player_identity',
            'username_like' => '%"username":"' . str_replace(['%', '_'], ['\\%', '\\_'], $identifier) . '"%',
        ]);
    }

    foreach ($stmt->fetchAll() as $row) {
        $identity = viewer_extract_player_identity(
            isset($row['payload_json']) && is_string($row['payload_json']) ? $row['payload_json'] : null,
            isset($row['player_uuid']) && is_string($row['player_uuid']) ? $row['player_uuid'] : null
        );
        if ($identity === null) {
            continue;
        }
        if (!viewer_is_uuid($identity['player_uuid'])) {
            continue;
        }
        if (!viewer_is_uuid($identifier) && strcasecmp($identity['player_name'], $identifier) !== 0) {
            continue;
        }
        viewer_upsert_player_index(
            $identity['player_name'],
            $identity['player_uuid'],
            'sync_table',
            isset($row['updated_at']) ? (int) $row['updated_at'] : null
        );
        return [
            'player_name' => $identity['player_name'],
            'player_uuid' => $identity['player_uuid'],
            'source' => 'sync_table',
        ];
    }

    return null;
}

function viewer_find_pending_player_uuid(string $playerName): ?string
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('SELECT player_uuid FROM ' . $tables['pending_ops'] . ' WHERE player_name = :player_name AND player_uuid IS NOT NULL AND player_uuid <> "" ORDER BY updated_at DESC LIMIT 1');
    $stmt->execute([
        'player_name' => trim($playerName),
    ]);
    $uuid = $stmt->fetchColumn();
    return is_string($uuid) && $uuid !== '' ? $uuid : null;
}

function viewer_promote_pending_ops_for_player(string $playerName, string $playerUuid): void
{
    $playerName = trim($playerName);
    $playerUuid = trim($playerUuid);
    if ($playerName === '' || $playerUuid === '' || !viewer_is_uuid($playerUuid)) {
        return;
    }

    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('UPDATE ' . $tables['pending_ops'] . ' SET player_uuid = :player_uuid, updated_at = :updated_at WHERE player_name = :player_name AND (player_uuid IS NULL OR player_uuid = "") AND status = :status');
    $stmt->execute([
        'player_uuid' => $playerUuid,
        'updated_at' => (int) round(microtime(true) * 1000),
        'player_name' => $playerName,
        'status' => 'pending',
    ]);
}

function viewer_recent_players(int $limit = 12): array
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('SELECT player_name AS name, player_uuid AS uuid, source FROM ' . $tables['player_index'] . ' ORDER BY last_seen_at DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function viewer_resolve_player(string $identifier): array
{
    $identifier = trim($identifier);
    $usercache = viewer_load_usercache();

    if ($identifier !== '' && viewer_is_uuid($identifier)) {
        $entry = $usercache['by_uuid'][strtolower($identifier)] ?? null;
        $indexed = $entry === null ? viewer_lookup_player_index_by_uuid($identifier) : null;
        $identity = ($entry === null && $indexed === null) ? viewer_find_player_identity_in_sync_table($identifier) : null;
        if ($entry !== null) {
            viewer_upsert_player_index((string) $entry['name'], $identifier, 'usercache');
            viewer_promote_pending_ops_for_player((string) $entry['name'], $identifier);
        } elseif ($indexed !== null) {
            viewer_promote_pending_ops_for_player((string) $indexed['player_name'], $identifier);
        } elseif ($identity !== null) {
            viewer_promote_pending_ops_for_player((string) $identity['player_name'], $identifier);
        }
        return [
            'identifier' => $identifier,
            'player_name' => $entry['name'] ?? $indexed['player_name'] ?? $identity['player_name'] ?? $identifier,
            'player_uuid' => $identifier,
            'resolved' => true,
            'source' => $entry !== null ? 'usercache' : ($indexed['source'] ?? $identity['source'] ?? 'direct_uuid'),
        ];
    }

    $entry = $usercache['by_name'][strtolower($identifier)] ?? null;
    if ($entry !== null) {
        viewer_upsert_player_index((string) $entry['name'], (string) $entry['uuid'], 'usercache');
        viewer_promote_pending_ops_for_player((string) $entry['name'], (string) $entry['uuid']);
        return [
            'identifier' => $identifier,
            'player_name' => $entry['name'],
            'player_uuid' => $entry['uuid'],
            'resolved' => true,
            'source' => 'usercache',
        ];
    }

    $indexed = viewer_lookup_player_index_by_name($identifier);
    if ($indexed !== null) {
        viewer_promote_pending_ops_for_player((string) $indexed['player_name'], (string) $indexed['player_uuid']);
        return [
            'identifier' => $identifier,
            'player_name' => $indexed['player_name'],
            'player_uuid' => $indexed['player_uuid'],
            'resolved' => true,
            'source' => $indexed['source'] ?? 'player_index',
        ];
    }

    $identity = viewer_find_player_identity_in_sync_table($identifier);
    if ($identity !== null) {
        viewer_promote_pending_ops_for_player((string) $identity['player_name'], (string) $identity['player_uuid']);
        return [
            'identifier' => $identifier,
            'player_name' => $identity['player_name'],
            'player_uuid' => $identity['player_uuid'],
            'resolved' => true,
            'source' => $identity['source'],
        ];
    }

    $pendingUuid = viewer_find_pending_player_uuid($identifier);
    if ($pendingUuid !== null) {
        viewer_upsert_player_index($identifier, $pendingUuid, 'pending');
        viewer_promote_pending_ops_for_player($identifier, $pendingUuid);
        return [
            'identifier' => $identifier,
            'player_name' => $identifier,
            'player_uuid' => $pendingUuid,
            'resolved' => true,
            'source' => 'pending',
        ];
    }

    return [
        'identifier' => $identifier,
        'player_name' => $identifier,
        'player_uuid' => null,
        'resolved' => false,
        'source' => 'unknown',
    ];
}

function viewer_uuid_v4(): string
{
    $bytes = random_bytes(16);
    $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
    $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
    $hex = bin2hex($bytes);
    return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
}

function viewer_fetch_sync_record(string $playerUuid, string $dataKey): ?array
{
    $stmt = viewer_pdo()->prepare('SELECT player_uuid, data_key, payload_json, updated_at FROM ' . viewer_table_name() . ' WHERE player_uuid = :player_uuid AND data_key = :data_key LIMIT 1');
    $stmt->execute([
        'player_uuid' => $playerUuid,
        'data_key' => $dataKey,
    ]);
    $row = $stmt->fetch();
    return is_array($row) ? $row : null;
}

function viewer_fetch_player_records(string $playerUuid): array
{
    $stmt = viewer_pdo()->prepare('SELECT player_uuid, data_key, payload_json, updated_at FROM ' . viewer_table_name() . ' WHERE player_uuid = :player_uuid ORDER BY data_key ASC');
    $stmt->execute(['player_uuid' => $playerUuid]);

    $records = [];
    foreach ($stmt->fetchAll() as $row) {
        $records[$row['data_key']] = [
            'player_uuid' => $row['player_uuid'],
            'data_key' => $row['data_key'],
            'updated_at' => (int) $row['updated_at'],
            'payload' => viewer_decode_payload($row['payload_json']),
            'raw_payload' => $row['payload_json'],
        ];
    }
    return $records;
}

function viewer_upsert_sync_record(string $playerUuid, string $dataKey, string $payloadJson, ?int $updatedAt = null): void
{
    $updatedAt = $updatedAt ?? (int) round(microtime(true) * 1000);
    $sql = 'INSERT INTO ' . viewer_table_name() . ' (player_uuid, data_key, payload_json, updated_at) VALUES (:player_uuid, :data_key, :payload_json, :updated_at) '
        . 'ON DUPLICATE KEY UPDATE payload_json = IF(VALUES(updated_at) >= updated_at, VALUES(payload_json), payload_json), '
        . 'updated_at = GREATEST(updated_at, VALUES(updated_at))';
    $stmt = viewer_pdo()->prepare($sql);
    $stmt->execute([
        'player_uuid' => $playerUuid,
        'data_key' => $dataKey,
        'payload_json' => $payloadJson,
        'updated_at' => $updatedAt,
    ]);
}

function viewer_merge_pending_payload(string $operationType, ?string $existingPayloadJson, array $payload): string
{
    $existing = [];
    if ($existingPayloadJson !== null && trim($existingPayloadJson) !== '') {
        $decoded = json_decode($existingPayloadJson, true);
        if (is_array($decoded)) {
            $existing = $decoded;
        }
    }

    return match ($operationType) {
        'mailbox_append' => json_encode([
            'mails' => json_decode(viewer_merge_mailbox_payload(
                json_encode($existing['mails'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                isset($payload['mails']) && is_array($payload['mails']) ? $payload['mails'] : []
            ), true) ?: [],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'skins_merge', 'progression_merge', 'stats_merge', 'mailbox_replace', 'nametags_merge' => json_encode(array_replace($existing, $payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        default => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    };
}

function viewer_list_pending_ops(int $limit = 100): array
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('SELECT * FROM ' . $tables['pending_ops'] . ' ORDER BY created_at DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function viewer_list_global_mails(int $limit = 50): array
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $stmt = viewer_pdo()->prepare('SELECT * FROM ' . $tables['global_mail'] . ' ORDER BY created_at DESC LIMIT :limit');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function viewer_queue_pending_op(string $playerName, ?string $playerUuid, string $dataKey, string $operationType, array $payload, ?string $note = null): int
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $now = (int) round(microtime(true) * 1000);

    $existingStmt = viewer_pdo()->prepare(
        'SELECT id, payload_json FROM ' . $tables['pending_ops']
        . ' WHERE player_name = :player_name AND data_key = :data_key AND operation_type = :operation_type AND status = :status'
        . ' ORDER BY updated_at DESC LIMIT 1'
    );
    $existingStmt->execute([
        'player_name' => $playerName,
        'data_key' => $dataKey,
        'operation_type' => $operationType,
        'status' => 'pending',
    ]);
    $existingRow = $existingStmt->fetch();
    if (is_array($existingRow)) {
        $mergedPayload = viewer_merge_pending_payload($operationType, (string) $existingRow['payload_json'], $payload);
        $updateStmt = viewer_pdo()->prepare('UPDATE ' . $tables['pending_ops'] . ' SET player_uuid = COALESCE(:player_uuid, player_uuid), payload_json = :payload_json, note = :note, updated_at = :updated_at WHERE id = :id');
        $updateStmt->execute([
            'player_uuid' => $playerUuid,
            'payload_json' => $mergedPayload,
            'note' => $note,
            'updated_at' => $now,
            'id' => $existingRow['id'],
        ]);
        return (int) $existingRow['id'];
    }

    $stmt = viewer_pdo()->prepare('INSERT INTO ' . $tables['pending_ops'] . ' (player_name, player_uuid, data_key, operation_type, payload_json, status, note, created_at, updated_at, applied_at) VALUES (:player_name, :player_uuid, :data_key, :operation_type, :payload_json, :status, :note, :created_at, :updated_at, NULL)');
    $stmt->execute([
        'player_name' => $playerName,
        'player_uuid' => $playerUuid,
        'data_key' => $dataKey,
        'operation_type' => $operationType,
        'payload_json' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'status' => 'pending',
        'note' => $note,
        'created_at' => $now,
        'updated_at' => $now,
    ]);
    return (int) viewer_pdo()->lastInsertId();
}

function viewer_build_mail_payload(string $sender, string $title, string $content, array $commands, int $expiresAt = 0): array
{
    return [
        'id' => viewer_uuid_v4(),
        'sender' => $sender !== '' ? $sender : 'System',
        'title' => $title,
        'content' => $content,
        'claimed' => false,
        'read' => false,
        'sentAt' => (int) round(microtime(true) * 1000),
        'expiresAt' => max(0, $expiresAt),
        'commands' => array_values(array_filter(array_map('trim', $commands), static fn(string $item): bool => $item !== '')),
    ];
}

function viewer_insert_global_mail(array $mail): void
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $now = (int) round(microtime(true) * 1000);
    $stmt = viewer_pdo()->prepare('INSERT INTO ' . $tables['global_mail'] . ' (id, sender, title, content, commands_json, sent_at, expires_at, active, created_at, updated_at) VALUES (:id, :sender, :title, :content, :commands_json, :sent_at, :expires_at, 1, :created_at, :updated_at)');
    $stmt->execute([
        'id' => $mail['id'],
        'sender' => $mail['sender'],
        'title' => $mail['title'],
        'content' => $mail['content'],
        'commands_json' => json_encode($mail['commands'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'sent_at' => $mail['sentAt'],
        'expires_at' => $mail['expiresAt'],
        'created_at' => $now,
        'updated_at' => $now,
    ]);
}

function viewer_merge_mailbox_payload(?string $existingPayload, array $mailObjects): string
{
    $existing = [];
    if ($existingPayload !== null && trim($existingPayload) !== '') {
        $decoded = json_decode($existingPayload, true);
        if (is_array($decoded)) {
            $existing = $decoded;
        }
    }

    $byId = [];
    foreach ($existing as $item) {
        if (is_array($item) && isset($item['id'])) {
            $byId[(string) $item['id']] = $item;
        }
    }
    foreach ($mailObjects as $mail) {
        if (is_array($mail) && isset($mail['id']) && !isset($byId[(string) $mail['id']])) {
            $byId[(string) $mail['id']] = $mail;
        }
    }
    return json_encode(array_values($byId), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function viewer_replace_mailbox_payload(array $mails): string
{
    $normalized = [];
    foreach ($mails as $mail) {
        if (!is_array($mail)) {
            continue;
        }
        $id = isset($mail['id']) && is_string($mail['id']) && trim($mail['id']) !== '' ? trim($mail['id']) : viewer_uuid_v4();
        $commands = isset($mail['commands']) && is_array($mail['commands']) ? $mail['commands'] : [];
        $commands = array_map(static function ($item): string {
            return is_string($item) ? trim($item) : '';
        }, $commands);
        $normalized[] = [
            'id' => $id,
            'sender' => isset($mail['sender']) && is_string($mail['sender']) ? trim($mail['sender']) : 'System',
            'title' => isset($mail['title']) && is_string($mail['title']) ? trim($mail['title']) : '',
            'content' => isset($mail['content']) && is_string($mail['content']) ? (string) $mail['content'] : '',
            'claimed' => !empty($mail['claimed']),
            'read' => !empty($mail['read']),
            'sentAt' => isset($mail['sentAt']) && is_numeric($mail['sentAt']) ? (int) $mail['sentAt'] : (int) round(microtime(true) * 1000),
            'expiresAt' => isset($mail['expiresAt']) && is_numeric($mail['expiresAt']) ? max(0, (int) $mail['expiresAt']) : 0,
            'commands' => array_values(array_filter($commands, static fn(string $item): bool => $item !== '')),
        ];
    }
    return json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function viewer_merge_stats_payload(?string $existingPayload, array $patch): string
{
    $payload = [];
    if ($existingPayload !== null && trim($existingPayload) !== '') {
        $decoded = json_decode($existingPayload, true);
        if (is_array($decoded)) {
            $payload = $decoded;
        }
    }

    $numericFields = [
        'totalPlayTime',
        'totalGamesPlayed',
        'totalKills',
        'totalDeaths',
        'totalWins',
        'totalLosses',
        'totalTeamKills',
        'totalLoversWins',
        'totalCivilianGames',
        'totalCivilianWins',
        'totalCivilianKills',
        'totalCivilianDeaths',
        'totalKillerGames',
        'totalKillerWins',
        'totalKillerKills',
        'totalKillerDeaths',
        'totalNeutralGames',
        'totalNeutralWins',
        'totalNeutralKills',
        'totalNeutralDeaths',
        'totalSheriffGames',
        'totalSheriffWins',
        'totalSheriffKills',
        'totalSheriffDeaths',
    ];
    foreach ($numericFields as $field) {
        if (isset($patch[$field]) && is_numeric($patch[$field])) {
            $payload[$field] = (int) $patch[$field];
        }
    }
    if (isset($patch['roleStats']) && is_array($patch['roleStats'])) {
        $payload['roleStats'] = $patch['roleStats'];
    }
    $payload['version'] = (int) round(microtime(true) * 1000);
    return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function viewer_merge_skins_payload(?string $existingPayload, array $patch): string
{
    $payload = [
        'equipped' => [],
        'unlocked' => [],
        'lootChance' => 0,
        'coinNum' => 0,
    ];
    if ($existingPayload !== null && trim($existingPayload) !== '') {
        $decoded = json_decode($existingPayload, true);
        if (is_array($decoded)) {
            $payload = array_replace($payload, $decoded);
        }
    }
    foreach (['coinNum', 'lootChance'] as $field) {
        if (isset($patch[$field]) && is_numeric($patch[$field])) {
            $payload[$field] = (int) $patch[$field];
        }
    }
    foreach (['equipped', 'unlocked'] as $field) {
        if (isset($patch[$field]) && is_array($patch[$field])) {
            $payload[$field] = $patch[$field];
        }
    }
    $payload['version'] = (int) round(microtime(true) * 1000);
    $payload['timestamp'] = (int) round(microtime(true) * 1000);
    return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function viewer_merge_progression_payload(?string $existingPayload, array $patch): string
{
    $payload = [
        'factionCards' => [],
    ];
    if ($existingPayload !== null && trim($existingPayload) !== '') {
        $decoded = json_decode($existingPayload, true);
        if (is_array($decoded)) {
            $payload = array_replace($payload, $decoded);
        }
    }
    foreach (['level', 'experience', 'totalExperience', 'claimedCoinRewards', 'claimedLootRewards', 'lastQuestRefreshTime', 'lastWeeklyRefreshTime'] as $field) {
        if (isset($patch[$field]) && is_numeric($patch[$field])) {
            $payload[$field] = (int) $patch[$field];
        }
    }
    if (isset($patch['factionCards']) && is_array($patch['factionCards'])) {
        $payload['factionCards'] = $patch['factionCards'];
    }
    if (isset($patch['factionCardsDelta']) && is_array($patch['factionCardsDelta'])) {
        foreach ($patch['factionCardsDelta'] as $cardKey => $delta) {
            if (!is_string($cardKey) || !is_numeric($delta)) {
                continue;
            }
            $current = 0;
            if (isset($payload['factionCards'][$cardKey]) && is_numeric($payload['factionCards'][$cardKey])) {
                $current = (int) $payload['factionCards'][$cardKey];
            }
            $payload['factionCards'][$cardKey] = max(0, $current + (int) $delta);
        }
    }
    $payload['version'] = (int) round(microtime(true) * 1000);
    return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function viewer_merge_nametags_payload(?string $existingPayload, array $patch): string
{
    $payload = [
        'nameTags' => [],
        'currentNametag' => '',
    ];
    if ($existingPayload !== null && trim($existingPayload) !== '') {
        $decoded = json_decode($existingPayload, true);
        if (is_array($decoded)) {
            $payload = array_replace($payload, $decoded);
        }
    }
    if (isset($patch['nameTags']) && is_array($patch['nameTags'])) {
        $payload['nameTags'] = array_values(array_filter(array_map(static function ($value): string {
            return is_string($value) ? trim($value) : '';
        }, $patch['nameTags']), static fn(string $value): bool => $value !== ''));
    }
    if (isset($patch['currentNametag']) && is_string($patch['currentNametag'])) {
        $payload['currentNametag'] = trim($patch['currentNametag']);
    }
    $payload['version'] = (int) round(microtime(true) * 1000);
    $payload['timestamp'] = (int) round(microtime(true) * 1000);
    return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function viewer_collect_known_player_uuids(?int $limit = null): array
{
    viewer_ensure_admin_schema();
    $limit = $limit ?? viewer_config_int('reconcile_batch_size', 500, 1, 5000);
    $uuids = [];
    foreach (viewer_load_usercache()['entries'] as $entry) {
        if (count($uuids) >= $limit) {
            break;
        }
        if (isset($entry['uuid']) && is_string($entry['uuid']) && viewer_is_uuid($entry['uuid'])) {
            $uuids[$entry['uuid']] = true;
        }
    }

    if (count($uuids) < $limit) {
        $tables = viewer_admin_table_names();
        $stmt = viewer_pdo()->prepare('SELECT player_uuid FROM ' . $tables['player_index'] . ' ORDER BY last_seen_at DESC LIMIT :limit');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        foreach ($stmt->fetchAll() as $row) {
            if (count($uuids) >= $limit) {
                break;
            }
            if (isset($row['player_uuid']) && is_string($row['player_uuid']) && viewer_is_uuid($row['player_uuid'])) {
                $uuids[$row['player_uuid']] = true;
            }
        }
    }

    if (count($uuids) < $limit) {
        $stmt = viewer_pdo()->prepare('SELECT player_uuid FROM ' . viewer_table_name() . ' GROUP BY player_uuid ORDER BY MAX(updated_at) DESC LIMIT :limit');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        foreach ($stmt->fetchAll() as $row) {
            if (count($uuids) >= $limit) {
                break;
            }
            if (isset($row['player_uuid']) && is_string($row['player_uuid']) && viewer_is_uuid($row['player_uuid'])) {
                $uuids[$row['player_uuid']] = true;
            }
        }
    }

    foreach (viewer_recent_players(min(200, $limit)) as $entry) {
        if (count($uuids) >= $limit) {
            break;
        }
        if (isset($entry['uuid']) && is_string($entry['uuid']) && viewer_is_uuid($entry['uuid'])) {
            $uuids[$entry['uuid']] = true;
        }
    }

    return array_keys($uuids);
}

function viewer_run_reconcile(): array
{
    viewer_ensure_admin_schema();
    $tables = viewer_admin_table_names();
    $pdo = viewer_pdo();
    $now = (int) round(microtime(true) * 1000);
    $batchSize = viewer_config_int('reconcile_batch_size', 500, 1, 5000);
    $report = [
        'processed' => 0,
        'pending_applied' => 0,
        'pending_waiting' => 0,
        'pending_conflicts' => 0,
        'global_mail_applied' => 0,
        'global_mail_waiting' => 0,
        'batch_size' => $batchSize,
    ];

    $pendingStmt = $pdo->prepare('SELECT * FROM ' . $tables['pending_ops'] . " WHERE status = 'pending' ORDER BY id ASC LIMIT :limit");
    $pendingStmt->bindValue(':limit', $batchSize, PDO::PARAM_INT);
    $pendingStmt->execute();
    $pendingRows = $pendingStmt->fetchAll();
    foreach ($pendingRows as $row) {
        $report['processed']++;
        $resolvedUuid = null;
        if (isset($row['player_uuid']) && is_string($row['player_uuid']) && $row['player_uuid'] !== '') {
            $resolvedUuid = $row['player_uuid'];
        } else {
            $resolvedUuid = viewer_resolve_player((string) $row['player_name'])['player_uuid'] ?? null;
        }
        if ($resolvedUuid === null || $resolvedUuid === '') {
            $report['pending_waiting']++;
            continue;
        }

        $payload = json_decode((string) $row['payload_json'], true);
        if (!is_array($payload)) {
            $payload = [];
        }

        $dataKey = (string) $row['data_key'];
        $existing = viewer_fetch_sync_record($resolvedUuid, $dataKey);
        $existingPayload = $existing['payload_json'] ?? null;

        try {
            switch ((string) $row['operation_type']) {
                case 'skins_merge':
                    $newPayload = viewer_merge_skins_payload($existingPayload, $payload);
                    break;
                case 'progression_merge':
                    $newPayload = viewer_merge_progression_payload($existingPayload, $payload);
                    break;
                case 'stats_merge':
                    $newPayload = viewer_merge_stats_payload($existingPayload, $payload);
                    break;
                case 'mailbox_append':
                    $newPayload = viewer_merge_mailbox_payload($existingPayload, isset($payload['mails']) && is_array($payload['mails']) ? $payload['mails'] : []);
                    break;
                case 'mailbox_replace':
                    $newPayload = viewer_replace_mailbox_payload(isset($payload['mails']) && is_array($payload['mails']) ? $payload['mails'] : []);
                    break;
                case 'nametags_merge':
                    $newPayload = viewer_merge_nametags_payload($existingPayload, $payload);
                    break;
                case 'raw_replace':
                default:
                    $newPayload = isset($payload['raw_payload']) && is_string($payload['raw_payload']) ? $payload['raw_payload'] : '{}';
                    break;
            }

            viewer_upsert_sync_record($resolvedUuid, $dataKey, $newPayload, $now);

            $updateStmt = $pdo->prepare('UPDATE ' . $tables['pending_ops'] . ' SET status = :status, player_uuid = :player_uuid, applied_at = :applied_at, updated_at = :updated_at WHERE id = :id');
            $updateStmt->execute([
                'status' => 'applied',
                'player_uuid' => $resolvedUuid,
                'applied_at' => $now,
                'updated_at' => $now,
                'id' => $row['id'],
            ]);
            $report['pending_applied']++;
        } catch (Throwable $throwable) {
            $report['pending_conflicts']++;
            $updateStmt = $pdo->prepare('UPDATE ' . $tables['pending_ops'] . ' SET note = :note, updated_at = :updated_at WHERE id = :id');
            $updateStmt->execute([
                'note' => mb_substr($throwable->getMessage(), 0, 240),
                'updated_at' => $now,
                'id' => $row['id'],
            ]);
        }
    }

    $mailRows = $pdo->query('SELECT * FROM ' . $tables['global_mail'] . ' WHERE active = 1 ORDER BY created_at ASC')->fetchAll();
    $globalMails = [];
    foreach ($mailRows as $row) {
        $commands = json_decode((string) $row['commands_json'], true);
        $globalMails[] = [
            'id' => $row['id'],
            'sender' => $row['sender'],
            'title' => $row['title'],
            'content' => $row['content'],
            'claimed' => false,
            'read' => false,
            'sentAt' => (int) $row['sent_at'],
            'expiresAt' => (int) $row['expires_at'],
            'commands' => is_array($commands) ? $commands : [],
        ];
    }

    if ($globalMails !== []) {
        $knownUuids = viewer_collect_known_player_uuids($batchSize);
        foreach ($knownUuids as $uuid) {
            $newMails = [];
            foreach ($globalMails as $mail) {
                $deliveryStmt = $pdo->prepare('SELECT 1 FROM ' . $tables['global_mail_delivery'] . ' WHERE mail_id = :mail_id AND player_uuid = :player_uuid LIMIT 1');
                $deliveryStmt->execute([
                    'mail_id' => $mail['id'],
                    'player_uuid' => $uuid,
                ]);
                if ($deliveryStmt->fetchColumn()) {
                    continue;
                }
                $newMails[] = $mail;
            }
            if ($newMails === []) {
                continue;
            }

            $existing = viewer_fetch_sync_record($uuid, 'mailbox');
            $existingPayload = $existing['payload_json'] ?? null;
            $newPayload = viewer_merge_mailbox_payload($existingPayload, $newMails);
            if ($existingPayload !== $newPayload) {
                viewer_upsert_sync_record($uuid, 'mailbox', $newPayload, $now);
            }
            foreach ($newMails as $mail) {
                $insertStmt = $pdo->prepare('INSERT IGNORE INTO ' . $tables['global_mail_delivery'] . ' (mail_id, player_uuid, delivered_at) VALUES (:mail_id, :player_uuid, :delivered_at)');
                $insertStmt->execute([
                    'mail_id' => $mail['id'],
                    'player_uuid' => $uuid,
                    'delivered_at' => $now,
                ]);
            }
            $report['global_mail_applied'] += count($newMails);
        }
        $report['global_mail_waiting'] = 0;
    }

    return $report;
}
