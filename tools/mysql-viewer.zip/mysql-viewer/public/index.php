<?php

declare(strict_types=1);

require __DIR__ . '/_app/bootstrap.php';

// Public page — no auth required
$config = viewer_config();
$siteTitle = (string) ($config['site_title'] ?? 'StarRailExpress');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8') ?> — 玩家查询</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
    <div class="page-shell">

        <header class="pub-topbar">
            <div class="pub-brand">
                <p class="eyebrow">快车谋杀案</p>
                <h1 class="pub-title"><?= htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8') ?></h1>
            </div>
            <a class="ghost-link pub-admin-link" href="./login.php?next=./admin.php">管理员</a>
        </header>

        <section class="pub-search-hero panel">
            <h2 class="pub-search-title">查询玩家数据</h2>
            <p class="pub-search-desc">输入你的游戏用户名，查看统计、成长、皮肤等数据。</p>
            <form id="search-form" class="pub-search-form" autocomplete="off">
                <input id="username-input" type="text" placeholder="输入用户名…" autocomplete="off" spellcheck="false">
                <button class="primary-button" type="submit">查询</button>
            </form>
            <div id="search-notice" class="notice-box" style="display:none;margin-top:14px;"></div>
        </section>

        <div id="dashboard-root" style="display:none;">

            <div id="player-header" class="pub-player-header panel">
                <div class="pub-player-avatar" id="player-avatar-wrap"></div>
                <div class="pub-player-info">
                    <p class="eyebrow" id="player-source-badge">已同步</p>
                    <h2 id="player-username" class="pub-player-name">—</h2>
                    <p id="player-uuid" class="pub-player-uuid muted-text">—</p>
                </div>
            </div>

            <div class="pub-dashboard-grid" id="dashboard-sections">

                <section class="panel pub-section">
                    <h3 class="pub-section-title">总体统计</h3>
                    <div id="table-stats" class="pub-stat-table-wrap"></div>
                </section>

                <section class="panel pub-section">
                    <h3 class="pub-section-title">成长进度</h3>
                    <div id="table-progress" class="pub-stat-table-wrap"></div>
                    <h3 class="pub-section-title" style="margin-top:20px;">阵营卡持有</h3>
                    <div id="table-faction-cards" class="pub-stat-table-wrap"></div>
                </section>

                <section class="panel pub-section">
                    <h3 class="pub-section-title">阵营战绩</h3>
                    <div id="table-factions" class="pub-faction-table-wrap"></div>
                </section>

                <section class="panel pub-section">
                    <h3 class="pub-section-title">皮肤 &amp; 邮件</h3>
                    <h4 class="pub-sub-title">皮肤概况</h4>
                    <div id="table-skins" class="pub-stat-table-wrap"></div>
                    <h4 class="pub-sub-title" style="margin-top:18px;">邮件概况</h4>
                    <div id="table-mail" class="pub-stat-table-wrap"></div>
                </section>

                <section class="panel pub-section pub-section-wide" id="role-section" style="display:none;">
                    <h3 class="pub-section-title">角色战绩 <span class="panel-meta" id="role-count"></span></h3>
                    <div id="table-roles" class="pub-role-table-wrap"></div>
                </section>

            </div>
        </div>

    </div>
    <script src="./assets/app.js"></script>
</body>
</html>