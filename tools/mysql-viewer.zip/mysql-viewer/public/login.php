<?php

declare(strict_types=1);

require __DIR__ . '/_app/bootstrap.php';

$config = viewer_config();
$siteTitle = (string) ($config['site_title'] ?? 'StarRailExpress Sync Viewer');

$auth = viewer_auth_config();
if (!$auth['enabled']) {
    header('Location: ./index.php', true, 302);
    exit;
}

$next = viewer_query_string('next', './index.php');
if ($next === '' || str_starts_with($next, 'http://') || str_starts_with($next, 'https://')) {
    $next = './index.php';
}

$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $username = isset($_POST['username']) && is_string($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) && is_string($_POST['password']) ? (string) $_POST['password'] : '';

    if (viewer_verify_login($username, $password)) {
        viewer_login($username);
        header('Location: ' . $next, true, 302);
        exit;
    }
    $error = '用户名或密码错误';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8') ?> Login</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
    <div class="auth-shell">
        <div class="auth-card panel">
            <p class="eyebrow">Secure Access</p>
            <h1 class="admin-title">登录 <?= htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8') ?></h1>
            <p class="hero-text">请输入站点账号后继续访问数据面板。</p>
            <?php if ($error !== ''): ?>
                <div class="notice-box" data-kind="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <form method="post" class="admin-form-stack compact-form">
                <input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">
                <label>
                    <span>用户名</span>
                    <input name="username" type="text" required autocomplete="username">
                </label>
                <label>
                    <span>密码</span>
                    <input name="password" type="password" required autocomplete="current-password">
                </label>
                <button class="primary-button" type="submit">登录</button>
            </form>
        </div>
    </div>
</body>
</html>