# StarRailExpress MySQL Data Viewer

这是一个适合部署在数据库服务器上的中控站点，使用 Nginx 提供静态资源，PHP-FPM 负责查询和写入 MySQL。

功能：

- 查看 sre_player_sync_data 表中的所有玩家同步数据
- 按 player_uuid、data_key 搜索和查看 JSON payload
- 通过 usercache 中的玩家名或 ID 解析并操作玩家数据，不必手输 UUID
- 编辑 skins、progression、mailbox、stats、nametags 等原始 JSON
- 提供皮肤系统、通行证系统、定向邮件、全局邮件的快捷表单
- 支持快速给予阵营卡，不必手改 progression JSON
- 为未入库玩家创建待投递操作，等 usercache 或数据库索引识别出 UUID 后自动补偿

目录结构：

- public/: 站点根目录
- public/_app/: PHP 公共逻辑与本地配置
- nginx/: Nginx 站点配置示例

部署建议：

1. 安装 Nginx、PHP-FPM、pdo_mysql。
2. 将当前目录放到服务器，例如 /var/www/starrailexpress-mysql-viewer。
3. 在服务器上创建 public/_app/config.php，内容参考 public/_app/config.sample.php，并填写数据库账号。
4. 在 config.php 中额外配置 usercache_path，指向服务端同步出来的 usercache.json。
5. 配置 auth：建议设置 auth.username、auth.password_hash（由 password_hash 生成）。auth.enabled 默认就是 true。
6. 站点首页是 public/index.php，管理后台入口是 public/admin.php，未登录会跳到 public/login.php。
6. 将 nginx/starrailexpress-data-viewer.conf 放到 Nginx 站点配置目录，修改 root 和 fastcgi_pass。
7. 重载 Nginx 与 PHP-FPM。

admin.php 首次访问时会自动建四张辅助表：

- <table_prefix>admin_pending_ops: 未解析玩家或延迟投递操作
- <table_prefix>admin_global_mail: 全局邮件定义
- <table_prefix>admin_global_mail_delivery: 全局邮件投递记录，避免重复投递
- <table_prefix>admin_player_index: 玩家名和 UUID 的数据库侧索引，供 usercache 缺失时继续按用户名操作

用户名解析顺序：

- 先查 usercache_path 指向的 usercache.json
- 再查 <table_prefix>admin_player_index
- 最后回看已有 pending 记录中是否已经拿到过该用户名对应的 UUID

定向邮件支持直接填写用户名作为收件人：

- 如果当下能解析出 UUID，就直接改对应 mailbox
- 如果暂时解析不到，就合并进该用户名的 pending 邮件队列
- 后续执行 reconcile 或 usercache 刷新后，会自动补投到真实玩家数据

安全建议：

- 给这个站点单独准备数据库账号，至少授予目标同步表和 admin 辅助表的 SELECT、INSERT、UPDATE、DELETE；首次建表还需要 CREATE
- 给 Nginx 站点加 Basic Auth 或内网访问限制
- 不要直接暴露到公网，尤其是 admin.php
- 不要把 config.php 提交到公开仓库
- 不要长期使用 auth.password_plain，部署后应切换到 auth.password_hash

性能说明：

- admin_overview 仅做概览查询，不再自动执行 reconcile。
- 玩家索引刷新改为手动触发（中控台“刷新玩家索引”按钮），避免每次打开页面扫描 player_identity。
- reconcile 改为手动触发（中控台“执行补偿”按钮），并按 reconcile_batch_size 分批执行。
- 全局邮件通过 admin_global_mail_delivery 记录已投递玩家，重复执行补偿不会重复写入同一封邮件。
- 可在中控台点击“优化索引”尝试为主同步表添加 (data_key, updated_at) 和 (player_uuid, updated_at) 索引；数据库账号无 ALTER 权限时会跳过。

可选配置：

- identity_sync_batch_size: 每次刷新 player_identity 索引的批量大小，默认 500。
- reconcile_batch_size: 每次补偿 pending 和全局邮件的批量大小，默认 500。
- recent_player_limit: 管理台最近玩家展示数量，默认 30。

默认查询表名是 sre_player_sync_data。如果你的表前缀不同，可以在 config.php 里修改 table_name。

宝塔说明：

- 宝塔常见的 open_basedir 会把 PHP 限定在站点根目录，也就是 public。
- 当前目录结构已经兼容这个限制，不需要再 require public 外层目录。
- 如果你之前用的是旧版本目录，请把 public/_app 下的新文件一起上传，并改用 public/_app/config.php。
- 如果要用玩家名直接操作，请确保宝塔站点可读到 usercache_path 指向的文件。
